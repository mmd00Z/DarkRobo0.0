/********************************************
 My HC-SR04 library
 This library is for sensing & get distance with HC-SR04,HC-SR05 ultrasonic sensor
 This program is free software
 Maker : MMD
 Dark Robo ...
 September 2021
*********************************************/

#ifndef _SR04_H_INCLUDED_
#define _SR04_H_INCLUDED_

#define SPEED_OF_SOUND 0.0343

#include <Arduino.h>

class SR04{
  private:
    int pinTrig, pinEcho;
	
  public:
	//setters
	void setTrigPin(short pinTrig);
	void setEchoPin(short pinEcho);
	
	// getters
	short getTrigPin();
	short getEchoPin();
	
	//Constructor
	SR04();
	SR04 (int trig, int echo);
	// A constructor for initializing and set trig pin and echo pin
	
    void init(int trig, int echo);
	// Initialize module and set trig pin and echo pin
	
    float getCm();
	// Get float distance value per Cm
	
    float getM();
	// Get float distance value per Meter
	
    int getCmInt();
	// Get integer distance value per Cm

};

#endif

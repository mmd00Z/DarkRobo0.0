
#include "HCSR04.h"

//setters
void SR04::setTrigPin(short pinTrig) {
	SR04::pinTrig = pinTrig;
}

void SR04::setEchoPin(short pinEcho) {
	SR04::pinEcho = pinEcho;
}

// getters
short SR04::getTrigPin() {
	return SR04::pinTrig;
}

short SR04::getEchoPin() {
	return SR04::pinEcho;
}

SR04::SR04 (){
} 

SR04::SR04 (int trig, int echo) {
  pinTrig = trig;
  pinEcho = echo;
  pinMode(pinTrig, OUTPUT);
  pinMode(pinEcho, INPUT ); 
}

void SR04::init(int trig, int echo){
  pinTrig = trig;
  pinEcho = echo;
  pinMode(pinTrig, OUTPUT);
  pinMode(pinEcho, INPUT ); 
}

float SR04::getCm() // get float distance value
{ 
  unsigned long duration;
  // send pulse
  digitalWrite(pinTrig,HIGH);
  delayMicroseconds(20);
  digitalWrite(pinTrig, LOW);
  // Computing duration time
  duration = pulseIn(pinEcho, HIGH); // get time of sound pulse in microsecond
  // time --> distance whit sound speed formula
  return (duration*SPEED_OF_SOUND)/2.0;
}

float SR04::getM(){
	return getCm()/100.0;
}

int SR04::getCmInt(){
	return int(getCm());
}


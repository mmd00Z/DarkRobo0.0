/********************************************
 My Move Robot library
 This class is for use L298 Driver Motor and robot moving control
 Maker : mmd
 Dark Robo ...
*********************************************/


#ifndef _MOVE_ROBOT_INCLUDED_
#define _MOVE_ROBOT_INCLUDED_

// Definition sides code
/* Not completed *****!!!!
#define FORWARD       0
#define BACKWARD      1
#define LEFT          2
#define RIGHT         3
#define LFTT_REVERSE  4
#define RIGHT_REVERSE 5
#define STOP          6
*/

#include <Arduino.h>

class MoveRobot
{
  private:
	//// Channel A //// ---->> motor left
	short Pin1A; // sample = 8 ;
	short Pin2A; // sample = 9 ;
	short enA;   // sample = 10; ==> must be ~PWM pin
	//// Channel B //// ---->> motor right
	short Pin1B; // sample = 13;
	short Pin2B; // sample = 12;
	short enB;   // sample = 11; ==> must be ~PWM pin
  public:
	// inputs init function
	// 1- mLeftPin1 --> The first pin of the left motor
	// 2- mLeftPin2 --> The second pin of the left motor
	// 3- mLeftPinEN--> Left motor pin EN(enable)
	// 4- mLeftPin1 --> The first pin of the right motor
	// 5- mLeftPin2 --> The second pin of the right motor
	// 6- mLeftPinEN--> Right motor pin EN(enable)
    void init(short mLeftPin1, short mLeftPin2,short mLeftPinEN, short mRightPin1, short mRightPin2,short mRightPinEN);
	
	// General move function for move to all sides
	// Not completed *****!!!!
	//bool move(char move_type);
	
	// left motor -> forward	|	Right motor -> forward
	void forward(int speed_left, int speed_right); // Move forward
	
	// left motor -> backward	|	Right motor -> backward
	void backward(int speed_left, int speed_right); // Move backward
	
	// left motor -> stop	|	Right motor -> forward
	void left(int speed1);  // Move left
	
	// left motor -> forward	|	Right motor -> stop
	void right(int speed1); // Move right
    
	// left motor -> backward	|	Right motor -> forward
	void left_reverse  (int speed_left, int speed_right);
	
	// left motor -> forward	|	Right motor -> backward
	void right_reverse (int speed_left, int speed_right);
	
	// left motor -> stop	|	Right motor -> stop
    void Stop(); // Stop moving
};


#endif


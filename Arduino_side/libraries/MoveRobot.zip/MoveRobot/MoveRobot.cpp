#include "MoveRobot.h"

void MoveRobot::init(short mLeftPin1, short mLeftPin2,short mLeftPinEN, short mRightPin1, short mRightPin2,short mRightPinEN){
  Pin1A = mLeftPin1;
  Pin2A = mLeftPin2;
  Pin1B = mRightPin1;
  Pin2B = mRightPin2;
  enA = mLeftPinEN;
  enB = mRightPinEN;
  pinMode(Pin1A, OUTPUT);
  pinMode(Pin2A, OUTPUT);
  pinMode(Pin1B, OUTPUT);
  pinMode(Pin2B, OUTPUT);
  //pinMode(enA  , OUTPUT);
  //pinMode(enB  , OUTPUT);
}

/* bool MoveRobot::move(char move_type){
	
} */

void MoveRobot::forward(int speed_left, int speed_right){
	digitalWrite(Pin1A, HIGH);
	digitalWrite(Pin2A, LOW);
	digitalWrite(Pin1B, HIGH);
	digitalWrite(Pin2B, LOW);
	  
	analogWrite(enA, speed_left);
	analogWrite(enB, speed_right);
}

void MoveRobot::backward(int speed_left, int speed_right){
	digitalWrite(Pin2A, HIGH); // back
	digitalWrite(Pin1A, LOW);
	digitalWrite(Pin2B, HIGH);
	digitalWrite(Pin1B, LOW);
	  
	analogWrite(enA, speed_left);
	analogWrite(enB, speed_right);
}

void MoveRobot::right(int speed1){
  digitalWrite(Pin1A, HIGH); // motor left  --> front
  digitalWrite(Pin2A, LOW);
  digitalWrite(Pin1B, HIGH); // motor right --> stop
  digitalWrite(Pin2B, HIGH);
  
  analogWrite(enA, speed1);
  analogWrite(enB, speed1);
}

void MoveRobot::left(int speed1){
  digitalWrite(Pin1A, HIGH); // motor left  --> stop
  digitalWrite(Pin2A, HIGH);
  digitalWrite(Pin1B, HIGH); // motor right --> front
  digitalWrite(Pin2B, LOW);
  
  analogWrite(enA, speed1);
  analogWrite(enB, speed1);
}

void MoveRobot::left_reverse (int speed_left, int speed_right)
{
  digitalWrite(Pin1A, LOW);  // left  --> back  |
  digitalWrite(Pin2A, HIGH); //                 |  = left
  digitalWrite(Pin1B, HIGH); // right --> front |
  digitalWrite(Pin2B, LOW);
	  
  analogWrite(enA, speed_left);
  analogWrite(enB, speed_right);
} 

void MoveRobot::right_reverse (int speed_left, int speed_right)
{
  digitalWrite(Pin1A, HIGH); // left  --> front |
  digitalWrite(Pin2A, LOW);  //                 |  = right
  digitalWrite(Pin1B, LOW);  // right --> back  |
  digitalWrite(Pin2B, HIGH);
  
  analogWrite(enA, speed_left);
  analogWrite(enB, speed_right);
}

void MoveRobot::Stop()
{
  digitalWrite(Pin1A, HIGH);
  digitalWrite(Pin2A, HIGH);
  digitalWrite(Pin1B, HIGH);
  digitalWrite(Pin2B, HIGH);
  
  analogWrite(enA, 255);
  analogWrite(enB, 255);
}


// a lots of notes..........
//_______________________________________________________________________________________________________________________

const int mobile_notes[]={NOTE_C4, NOTE_DS4, NOTE_G4, NOTE_C4, NOTE_DS4, NOTE_G4, NOTE_F4, NOTE_DS4, NOTE_F4, NOTE_DS4};
const char mobile_durations[]={8,8,4,8,8,8,8,16,16,2}; // 4= Note Siah   8= Note Chang

const int block_notes[]={NOTE_G4, NOTE_GS4, NOTE_A4, NOTE_AS4, NOTE_B4};
const char block_durations[]={8, 8, 8, 8, 8};

const int damage_notes[]={NOTE_A3, NOTE_F3, NOTE_A2, 0, NOTE_A3, NOTE_F3, NOTE_A2, 0, NOTE_A3, NOTE_F3, NOTE_A2};
const char damage_durations[]={8, 8, 8, 12, 8, 8, 8, 12, 8, 8, 8};

const int melody_notes[]={NOTE_C4, NOTE_G3,NOTE_G3, NOTE_GS3, NOTE_G3,0, NOTE_B3, NOTE_C4};
const char melody_durations[]={4, 8, 8, 4, 4, 4, 4, 4}; // 4= Note Siah   8= Note Chang

//##############**"HE IS A PIRATE" Theme song of Pirates of caribbean**##############// --->> Dozdane Daryayi e kara'ib
const int pirates_notes[] = {NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, 
NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_D4, NOTE_A3, NOTE_C4, NOTE_D4, NOTE_D4, NOTE_D4, 
NOTE_E4, NOTE_F4, NOTE_F4, NOTE_F4, NOTE_G4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_C4, NOTE_C4, NOTE_D4, 0, NOTE_A3, NOTE_C4, NOTE_B3, NOTE_D4, 
NOTE_B3, NOTE_E4, NOTE_F4,NOTE_F4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_C4, NOTE_D4, NOTE_C4, NOTE_D4, 0, 0, NOTE_A3, NOTE_C4, NOTE_D4, NOTE_D4, 
NOTE_D4, NOTE_F4,NOTE_G4, NOTE_G4, NOTE_G4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_A4, NOTE_G4, NOTE_A4, NOTE_D4, 0, NOTE_D4, NOTE_E3, NOTE_F4, 
NOTE_F4, NOTE_G4, NOTE_A4, NOTE_D4, 0, NOTE_D4, NOTE_F4, NOTE_E4, NOTE_E4, NOTE_F4, NOTE_D4};
const char pirates_durations[] = {4,8,4,8,4,8,8,8,8,4,8,4,8,4,8,8,8,8,4,8,4,8,4,8,8,8,8,4,4,8,8,4,4,8,8,4,4,8,8,8,4,8,8,8,4,4,8,8,4,4,8,8,4,4,8,4,4,8,
8,8,8,4,4,8,8,4,4,8,8,4,4,8,8,8,4,8,8,8,4,4,4,8,4,8,8,8,4,4,8,8};
//###########End of He is a Pirate song#############//

//##############**"Crazy Frog" song of Crazy frog album**##############// ---->> ghorbaghe ye divaneh
int crazyFrog_notes[] = {NOTE_D4, 0, NOTE_F4, NOTE_D4, 0, NOTE_D4, NOTE_G4, NOTE_D4, NOTE_C4,NOTE_D4, 0, NOTE_A4, NOTE_D4, 0, NOTE_D4, NOTE_AS4, 
NOTE_A4, NOTE_F4,NOTE_D4, NOTE_A4, NOTE_D5, NOTE_D4, NOTE_C4, 0, NOTE_C4, NOTE_A3, NOTE_E4, NOTE_D4, 0,NOTE_D4,NOTE_D4};
int crazyFrog_durations[] = {8, 8, 6, 16, 16, 16, 8, 8, 8, 8, 8, 6, 16, 16, 16, 8, 8, 8, 8, 8, 8, 16, 16, 16, 16, 8, 8, 2, 8, 4, 4};
//###########End of Crazy Frog#############//

//##############**"Mario underworld" **##############//
int marioUW_notes[] = {NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4,NOTE_AS3, NOTE_AS4, 0, 0,NOTE_C4, NOTE_C5, NOTE_A3, NOTE_A4, NOTE_AS3, NOTE_AS4, 0, 0,
NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4,NOTE_DS3, NOTE_DS4, 0, 0, NOTE_F3, NOTE_F4, NOTE_D3, NOTE_D4,NOTE_DS3, NOTE_DS4, 0, 0, NOTE_DS4, NOTE_CS4, 
NOTE_D4, NOTE_CS4, NOTE_DS4, NOTE_DS4, NOTE_GS3, NOTE_G3, NOTE_CS4, NOTE_C4, NOTE_FS4, NOTE_F4, NOTE_E3, NOTE_AS4, NOTE_A4, NOTE_GS4, NOTE_DS4, 
NOTE_B3,  NOTE_AS3, NOTE_A3, NOTE_GS3,0, 0, 0};
int marioUW_durations[] = {12, 12, 12, 12,12, 12, 6, 3, 12, 12, 12, 12, 12, 12, 6, 3, 12, 12, 12, 12, 12, 12, 6, 3, 12, 12, 12, 12,12, 12, 6, 6, 
18, 18, 18, 6, 6, 6, 6,6, 6, 18, 18, 18, 18, 18, 18, 10, 10, 10, 10, 10, 10, 3, 3, 3};
//###########End of Mario underworld#############//

//##############**"Titanic" **##############//
int titanic_notes[] = {NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_B4, NOTE_E4, NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_B4, 
NOTE_E4, NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_B4, NOTE_E4, NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_D5, NOTE_E4, NOTE_B4, 
NOTE_E5, NOTE_E5, NOTE_E5, NOTE_B4, NOTE_E4, NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_B4, NOTE_F5,NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5,
NOTE_E5, NOTE_B4, NOTE_E4, NOTE_E4, NOTE_B4, NOTE_E5, NOTE_E5, NOTE_E5, NOTE_D5, NOTE_E5, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_D4, NOTE_B3, NOTE_E4, 
NOTE_E4, NOTE_E4, NOTE_B3, NOTE_E4, NOTE_D4, NOTE_E4, NOTE_F4, NOTE_G4, NOTE_F4, NOTE_E4, NOTE_E4, NOTE_E4, NOTE_E4};
int titanic_durations[] = {8,8,8,8,8,8,4,8,8,8,8,8,8,4,8,8,8,8,8,8,4,8,8,8,8,4,4,8,8,8,8,8,8,4,8,8,8,8,8,8,4,8,8,8,8,8,8,1,8,8,8,8,4,4,4,8,4,4,8,
8,8,8,4,8,8,4,8,4,8,8,4,8,4,1};
//###########End of Titanic#############//

//_______________________________________________________________________________________________________________________


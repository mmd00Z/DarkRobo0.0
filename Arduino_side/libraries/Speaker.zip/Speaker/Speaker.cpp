#include "Speaker.h"
#include "SpeakerDataNotes.h"

// setter pin
void Speaker::setSpeakerPin(short speakerPin){
	Speaker::speakerPin = speakerPin;
}

// getter pin
void Speaker::getSpeakerPin(){
	return Speaker::speakerPin;
}

void Speaker::init(int pin) {
	speakerPin = pin;
}

void Speaker::mobile() {
for( int thisNote=0; thisNote < 10; thisNote++){
 int mobile_duration = 1000/mobile_durations[thisNote];
 tone(speakerPin, mobile_notes[thisNote],mobile_duration);
 //Tempo
 int pauseBetweenNotes = mobile_duration * 1.43;
 delay(pauseBetweenNotes);}
}

void Speaker::block() {
  for( int thisNote=0; thisNote < 5; thisNote++){
	int block_duration = 1000/block_durations[thisNote];
	tone(speakerPin, block_notes[thisNote],block_duration);
	//Tempo
	int pauseBetweenNotes = block_duration * 1.43;
	delay(pauseBetweenNotes);
  }
}

void Speaker::damage() {
  for( int thisNote=0; thisNote < 11; thisNote++){
	int damage_duration = 1000/damage_durations[thisNote];
	tone(speakerPin, damage_notes[thisNote],damage_duration);
	//Tempo
	int pauseBetweenNotes = damage_duration * 1.43;
	delay(pauseBetweenNotes);
  }
}

void Speaker::melody() {
  for( int thisNote=0; thisNote < 8; thisNote++){
  int melody_duration = 1000/melody_durations[thisNote];
  tone(speakerPin, melody_notes[thisNote],melody_duration);
  //Tempo
  int pauseBetweenNotes = melody_duration * 1.43;
  delay(pauseBetweenNotes);
  }
}

void Speaker::pirates_of_caribbean()
{
  for( int thisNote=0; thisNote < 90; thisNote++){
    int pirates_duration = 1000/pirates_durations[thisNote];
    tone(speakerPin, pirates_notes[thisNote], pirates_duration);
    //Tempo
    int pauseBetweenNotes = pirates_duration * 1.43;
    delay(pauseBetweenNotes);
  }
}

void Speaker::crazyFrog()
{
  for( int thisNote=0; thisNote < 31; thisNote++){
    int crazyFrog_duration = 1000/crazyFrog_durations[thisNote];
    tone(speakerPin, crazyFrog_notes[thisNote], crazyFrog_duration);
    //Tempo
    int pauseBetweenNotes = crazyFrog_duration * 1.43;
    delay(pauseBetweenNotes);
  }
}

void Speaker::marioUW()
{
  for( int thisNote=0; thisNote < 56; thisNote++){
    int marioUW_duration = 1000/marioUW_durations[thisNote];
    tone(speakerPin, marioUW_notes[thisNote], marioUW_duration);
    //Tempo
    int pauseBetweenNotes = marioUW_duration * 1.43;
    delay(pauseBetweenNotes);
  }
}

void Speaker::titanic()
{
  for( int thisNote=0; thisNote < 56; thisNote++){
    int titanic_duration = 1000/titanic_durations[thisNote];
    tone(speakerPin, titanic_notes[thisNote], titanic_duration);
    //Tempo
    int pauseBetweenNotes = titanic_duration * 1.43;
    delay(pauseBetweenNotes);
  }
}

bool Speaker::play(unsigned char select_music){
	switch(select_music){
		case MOBILE: Speaker::mobile(); return true;
		case BLOCK : Speaker::block (); return true;
		case DAMAGE: Speaker::damage(); return true;
		case MELODY: Speaker::melody(); return true;
		case PIRATES_OF_CARIBBEAN: Speaker::pirates_of_caribbean(); return true;
		case CRAZY_FROG      : Speaker::crazyFrog(); return true;
		case MARIO_UNDERWORLD: Speaker::marioUW  (); return true;
		case TITANIC         : Speaker::titanic  (); return true;
		default: return false;
	}
	return false;
}

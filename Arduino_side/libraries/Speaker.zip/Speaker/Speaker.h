/********************************************
 My Speaker Library
 This library is for play some music whit Ardoino tone function & a speaker
 maker : mmd
 Dark Robo ...
 
 List of music names(until now):
  1- Mobile
  2- Block
  3- Damage
  4- Melody
  5- Pirates of caribbean
  6- Crazy frog
  7- Mario underworld
  8- Titanic
*********************************************/


#ifndef _SPEAKER_INCLUDED_
#define _SPEAKER_INCLUDED_

#include "Speaker_config.h"

class Speaker {
  private:
    short speakerPin;
  public:
	// setter pin
	void setSpeakerPin(short lm35Pin);
	
	// getter pin
	void getSpeakerPin();
  
    // initializ and set pin of the speaker
    void init(int pin);
	
	// General player of all music
	bool play(unsigned char select_music);
	
    void mobile(); // Plays mobile music
	
    void block();  // Plays block  music
	
    void damage(); // Plays damage music
	
    void melody(); // Plays melody music
	
	void pirates_of_caribbean();  // Plays pirates of caribbean music

	void crazyFrog(); // Plays Crazy frog music

	void marioUW(); // Plays Mario underworld music

	void titanic(); // Plays titanic music
};



#endif

/*
 * Speaker_config
 * 
 * modified on september 2021
 */

#ifndef __SPEAKER_CONFIG_INCLUDED__
#define __SPEAKER_CONFIG_INCLUDED__

#include <Arduino.h>

// include "pitches" library
#ifndef _PITCHES_INCLUDED_
#include "pitches.h"
#endif

// Definition musics code
#define MOBILE                0
#define BLOCK                 1
#define DAMAGE                2
#define MELODY                3
#define PIRATES_OF_CARIBBEAN  4
#define CRAZY_FROG            5
#define MARIO_UNDERWORLD      6
#define TITANIC               7

#endif

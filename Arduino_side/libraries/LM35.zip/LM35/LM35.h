/********************************************
 My Temperature Library
 This library is for sensing & get temperature with LM35 sensor
 Maker : Mohammadreza Gholami
 Dark Robo ...
*********************************************/

#ifndef _LM35_H_INCLUDED_
#define _LM35_H_INCLUDED_

#define FAHRENHEIT 1
#define KELVIN 0

#include <Arduino.h>
class LM35{
  private:
    short lm35Pin;
	
  public:
	// setter pin
	void setPinLM35(short lm35Pin);
	
	// getter pin
	void getPinLM35();
	
	//Constructor
	// Sensor pin must be analog pin (sample for Ardoino UNO: A0 to A5)
	LM35(short Sensor_pin);
	
    // Sensor pin must be analog pin (sample for Ardoino UNO: A0 to A5)
    void init(short Sensor_pin);
    
	// return flot value of Temperature per Centigrade
    float getTemperature();
    
    // return flot value of Temperature per Fahrenheit
    // if isFahrenheit=true --> return temp in Fahrenheit  |  isFahrenheit=false --> return temp in Kelvin
    float getTemperature(bool isFahrenheit);
	
	// return int value of Temperature per Centigrade
	int getTemperatureI();
	
	// return int value of Temperature per Fahrenheit
    // if isFahrenheit=true --> return temp in Fahrenheit  |  isFahrenheit=false --> return temp in Kelvin
    int getTemperatureI(bool isFahrenheit);
    
};

#endif

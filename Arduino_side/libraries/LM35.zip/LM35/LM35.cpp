#include "LM35.h"


// setter pin
void LM35::setPinLM35(short lm35Pin){
	LM35::lm35Pin = lm35Pin;
}

// getter pin
void LM35::getPinLM35(){
	return LM35::lm35Pin;
}

LM35::LM35(short Sensor_pin){
	lm35Pin = Sensor_pin; 
} 

void LM35::init(short Sensor_pin){
	lm35Pin = Sensor_pin;  
}

float LM35::getTemperature(){ 
    //float temp = analogRead(lm35Pin); // 0 to 1023
    //temp *= 0.4882; // temp = (temp*500.0)/1023 or temp = (temp*4.882)/10 ==> ADC to temperature
    return analogRead(lm35Pin)*0.4882;
}

float LM35::getTemperature(bool isFahrenheit){
	return (isFahrenheit)? (getTemperature()*1.8)+32.0:getTemperature()+273.15;
}

int LM35::getTemperatureI(){ 
	return int(getTemperature()); 
}

int LM35::getTemperatureI(bool isFahrenheit){
	return int(getTemperature(isFahrenheit)); 
}


package com.DarkRobo.mmd;

import anywheresoftware.b4a.BA;
import android.widget.Button;
import android.view.View.OnTouchListener;
import android.view.MotionEvent;
import android.view.View;

import anywheresoftware.b4a.B4AMenuItem;
import android.app.Activity;
import android.os.Bundle;
import anywheresoftware.b4a.BA;
import anywheresoftware.b4a.BALayout;
import anywheresoftware.b4a.B4AActivity;
import anywheresoftware.b4a.ObjectWrapper;
import anywheresoftware.b4a.objects.ActivityWrapper;
import java.lang.reflect.InvocationTargetException;
import anywheresoftware.b4a.B4AUncaughtException;
import anywheresoftware.b4a.debug.*;
import java.lang.ref.WeakReference;

public class main extends Activity implements B4AActivity{
	public static main mostCurrent;
	static boolean afterFirstLayout;
	static boolean isFirst = true;
    private static boolean processGlobalsRun = false;
	BALayout layout;
	public static BA processBA;
	BA activityBA;
    ActivityWrapper _activity;
    java.util.ArrayList<B4AMenuItem> menuItems;
	public static final boolean fullScreen = true;
	public static final boolean includeTitle = false;
    public static WeakReference<Activity> previousOne;

	@Override
	public void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
        mostCurrent = this;
		if (processBA == null) {
			processBA = new BA(this.getApplicationContext(), null, null, "com.DarkRobo.mmd", "com.DarkRobo.mmd.main");
			processBA.loadHtSubs(this.getClass());
	        float deviceScale = getApplicationContext().getResources().getDisplayMetrics().density;
	        BALayout.setDeviceScale(deviceScale);
            
		}
		else if (previousOne != null) {
			Activity p = previousOne.get();
			if (p != null && p != this) {
                BA.LogInfo("Killing previous instance (main).");
				p.finish();
			}
		}
        processBA.setActivityPaused(true);
        processBA.runHook("oncreate", this, null);
		if (!includeTitle) {
        	this.getWindow().requestFeature(android.view.Window.FEATURE_NO_TITLE);
        }
        if (fullScreen) {
        	getWindow().setFlags(android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN,   
        			android.view.WindowManager.LayoutParams.FLAG_FULLSCREEN);
        }
		
        processBA.sharedProcessBA.activityBA = null;
		layout = new BALayout(this);
		setContentView(layout);
		afterFirstLayout = false;
        WaitForLayout wl = new WaitForLayout();
        if (anywheresoftware.b4a.objects.ServiceHelper.StarterHelper.startFromActivity(processBA, wl, false))
		    BA.handler.postDelayed(wl, 5);

	}
	static class WaitForLayout implements Runnable {
		public void run() {
			if (afterFirstLayout)
				return;
			if (mostCurrent == null)
				return;
            
			if (mostCurrent.layout.getWidth() == 0) {
				BA.handler.postDelayed(this, 5);
				return;
			}
			mostCurrent.layout.getLayoutParams().height = mostCurrent.layout.getHeight();
			mostCurrent.layout.getLayoutParams().width = mostCurrent.layout.getWidth();
			afterFirstLayout = true;
			mostCurrent.afterFirstLayout();
		}
	}
	private void afterFirstLayout() {
        if (this != mostCurrent)
			return;
		activityBA = new BA(this, layout, processBA, "com.DarkRobo.mmd", "com.DarkRobo.mmd.main");
        
        processBA.sharedProcessBA.activityBA = new java.lang.ref.WeakReference<BA>(activityBA);
        anywheresoftware.b4a.objects.ViewWrapper.lastId = 0;
        _activity = new ActivityWrapper(activityBA, "activity");
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (BA.isShellModeRuntimeCheck(processBA)) {
			if (isFirst)
				processBA.raiseEvent2(null, true, "SHELL", false);
			processBA.raiseEvent2(null, true, "CREATE", true, "com.DarkRobo.mmd.main", processBA, activityBA, _activity, anywheresoftware.b4a.keywords.Common.Density, mostCurrent);
			_activity.reinitializeForShell(activityBA, "activity");
		}
        initializeProcessGlobals();		
        initializeGlobals();
        
        BA.LogInfo("** Activity (main) Create, isFirst = " + isFirst + " **");
        processBA.raiseEvent2(null, true, "activity_create", false, isFirst);
		isFirst = false;
		if (this != mostCurrent)
			return;
        processBA.setActivityPaused(false);
        BA.LogInfo("** Activity (main) Resume **");
        processBA.raiseEvent(null, "activity_resume");
        if (android.os.Build.VERSION.SDK_INT >= 11) {
			try {
				android.app.Activity.class.getMethod("invalidateOptionsMenu").invoke(this,(Object[]) null);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}

	}
	public void addMenuItem(B4AMenuItem item) {
		if (menuItems == null)
			menuItems = new java.util.ArrayList<B4AMenuItem>();
		menuItems.add(item);
	}
	@Override
	public boolean onCreateOptionsMenu(android.view.Menu menu) {
		super.onCreateOptionsMenu(menu);
        try {
            if (processBA.subExists("activity_actionbarhomeclick")) {
                Class.forName("android.app.ActionBar").getMethod("setHomeButtonEnabled", boolean.class).invoke(
                    getClass().getMethod("getActionBar").invoke(this), true);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        if (processBA.runHook("oncreateoptionsmenu", this, new Object[] {menu}))
            return true;
		if (menuItems == null)
			return false;
		for (B4AMenuItem bmi : menuItems) {
			android.view.MenuItem mi = menu.add(bmi.title);
			if (bmi.drawable != null)
				mi.setIcon(bmi.drawable);
            if (android.os.Build.VERSION.SDK_INT >= 11) {
				try {
                    if (bmi.addToBar) {
				        android.view.MenuItem.class.getMethod("setShowAsAction", int.class).invoke(mi, 1);
                    }
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
			mi.setOnMenuItemClickListener(new B4AMenuItemsClickListener(bmi.eventName.toLowerCase(BA.cul)));
		}
        
		return true;
	}   
 @Override
 public boolean onOptionsItemSelected(android.view.MenuItem item) {
    if (item.getItemId() == 16908332) {
        processBA.raiseEvent(null, "activity_actionbarhomeclick");
        return true;
    }
    else
        return super.onOptionsItemSelected(item); 
}
@Override
 public boolean onPrepareOptionsMenu(android.view.Menu menu) {
    super.onPrepareOptionsMenu(menu);
    processBA.runHook("onprepareoptionsmenu", this, new Object[] {menu});
    return true;
    
 }
 protected void onStart() {
    super.onStart();
    processBA.runHook("onstart", this, null);
}
 protected void onStop() {
    super.onStop();
    processBA.runHook("onstop", this, null);
}
    public void onWindowFocusChanged(boolean hasFocus) {
       super.onWindowFocusChanged(hasFocus);
       if (processBA.subExists("activity_windowfocuschanged"))
           processBA.raiseEvent2(null, true, "activity_windowfocuschanged", false, hasFocus);
    }
	private class B4AMenuItemsClickListener implements android.view.MenuItem.OnMenuItemClickListener {
		private final String eventName;
		public B4AMenuItemsClickListener(String eventName) {
			this.eventName = eventName;
		}
		public boolean onMenuItemClick(android.view.MenuItem item) {
			processBA.raiseEventFromUI(item.getTitle(), eventName + "_click");
			return true;
		}
	}
    public static Class<?> getObject() {
		return main.class;
	}
    private Boolean onKeySubExist = null;
    private Boolean onKeyUpSubExist = null;
	@Override
	public boolean onKeyDown(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeydown", this, new Object[] {keyCode, event}))
            return true;
		if (onKeySubExist == null)
			onKeySubExist = processBA.subExists("activity_keypress");
		if (onKeySubExist) {
			if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK &&
					android.os.Build.VERSION.SDK_INT >= 18) {
				HandleKeyDelayed hk = new HandleKeyDelayed();
				hk.kc = keyCode;
				BA.handler.post(hk);
				return true;
			}
			else {
				boolean res = new HandleKeyDelayed().runDirectly(keyCode);
				if (res)
					return true;
			}
		}
		return super.onKeyDown(keyCode, event);
	}
	private class HandleKeyDelayed implements Runnable {
		int kc;
		public void run() {
			runDirectly(kc);
		}
		public boolean runDirectly(int keyCode) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keypress", false, keyCode);
			if (res == null || res == true) {
                return true;
            }
            else if (keyCode == anywheresoftware.b4a.keywords.constants.KeyCodes.KEYCODE_BACK) {
				finish();
				return true;
			}
            return false;
		}
		
	}
    @Override
	public boolean onKeyUp(int keyCode, android.view.KeyEvent event) {
        if (processBA.runHook("onkeyup", this, new Object[] {keyCode, event}))
            return true;
		if (onKeyUpSubExist == null)
			onKeyUpSubExist = processBA.subExists("activity_keyup");
		if (onKeyUpSubExist) {
			Boolean res =  (Boolean)processBA.raiseEvent2(_activity, false, "activity_keyup", false, keyCode);
			if (res == null || res == true)
				return true;
		}
		return super.onKeyUp(keyCode, event);
	}
	@Override
	public void onNewIntent(android.content.Intent intent) {
        super.onNewIntent(intent);
		this.setIntent(intent);
        processBA.runHook("onnewintent", this, new Object[] {intent});
	}
    @Override 
	public void onPause() {
		super.onPause();
        if (_activity == null)
            return;
        if (this != mostCurrent)
			return;
		anywheresoftware.b4a.Msgbox.dismiss(true);
        BA.LogInfo("** Activity (main) Pause, UserClosed = " + activityBA.activity.isFinishing() + " **");
        if (mostCurrent != null)
            processBA.raiseEvent2(_activity, true, "activity_pause", false, activityBA.activity.isFinishing());		
        processBA.setActivityPaused(true);
        mostCurrent = null;
        if (!activityBA.activity.isFinishing())
			previousOne = new WeakReference<Activity>(this);
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        processBA.runHook("onpause", this, null);
	}

	@Override
	public void onDestroy() {
        super.onDestroy();
		previousOne = null;
        processBA.runHook("ondestroy", this, null);
	}
    @Override 
	public void onResume() {
		super.onResume();
        mostCurrent = this;
        anywheresoftware.b4a.Msgbox.isDismissing = false;
        if (activityBA != null) { //will be null during activity create (which waits for AfterLayout).
        	ResumeMessage rm = new ResumeMessage(mostCurrent);
        	BA.handler.post(rm);
        }
        processBA.runHook("onresume", this, null);
	}
    private static class ResumeMessage implements Runnable {
    	private final WeakReference<Activity> activity;
    	public ResumeMessage(Activity activity) {
    		this.activity = new WeakReference<Activity>(activity);
    	}
		public void run() {
            main mc = mostCurrent;
			if (mc == null || mc != activity.get())
				return;
			processBA.setActivityPaused(false);
            BA.LogInfo("** Activity (main) Resume **");
            if (mc != mostCurrent)
                return;
		    processBA.raiseEvent(mc._activity, "activity_resume", (Object[])null);
		}
    }
	@Override
	protected void onActivityResult(int requestCode, int resultCode,
	      android.content.Intent data) {
		processBA.onActivityResult(requestCode, resultCode, data);
        processBA.runHook("onactivityresult", this, new Object[] {requestCode, resultCode});
	}
	private static void initializeGlobals() {
		processBA.raiseEvent2(null, true, "globals", false, (Object[])null);
	}
    public void onRequestPermissionsResult(int requestCode,
        String permissions[], int[] grantResults) {
        for (int i = 0;i < permissions.length;i++) {
            Object[] o = new Object[] {permissions[i], grantResults[i] == 0};
            processBA.raiseEventFromDifferentThread(null,null, 0, "activity_permissionresult", true, o);
        }
            
    }

public anywheresoftware.b4a.keywords.Common __c = null;
public static anywheresoftware.b4a.objects.Serial _serial1 = null;
public static anywheresoftware.b4a.objects.streams.File.TextWriterWrapper _tw = null;
public static anywheresoftware.b4a.objects.streams.File.TextReaderWrapper _tr = null;
public static anywheresoftware.b4a.objects.Timer _monitor = null;
public static String _language = "";
public static int _theme = 0;
public static String _str_check_blue = "";
public static String _str_check_blue_title = "";
public static String _str_connect_toblue = "";
public static String _str_msg_disconnect = "";
public static String _str_msg_connected = "";
public static String _str_msg_erorrinconnect = "";
public static String _str_title_erorrinconnect = "";
public static boolean _flag_stop_start_smartmove = false;
public static String _str_txt_settings = "";
public static String _str_txt_about = "";
public static String _str_error_overflow_speed = "";
public anywheresoftware.b4a.objects.ButtonWrapper _btnsettings = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnconnect = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndisconnect = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnbar = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldistancetxt = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbldistance = null;
public anywheresoftware.b4a.objects.EditTextWrapper _etspead = null;
public anywheresoftware.b4a.objects.SeekBarWrapper _sbspead = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltemp = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnspeaker = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnup = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnleft = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnright = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btndown = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnsmartmove = null;
public anywheresoftware.b4a.objects.ButtonWrapper _btnlomp1 = null;
public anywheresoftware.b4a.objects.LabelWrapper _lbltxtspeed = null;
public static String _pwm = "";
public static boolean _isonlomp = false;
public static boolean _isonsms = false;
public static int _temp = 0;
public static int _distance = 0;
public static boolean _isconnect = false;
public com.DarkRobo.mmd.actsettings _actsettings = null;
public com.DarkRobo.mmd.starter _starter = null;
public com.DarkRobo.mmd.actabout _actabout = null;

public static boolean isAnyActivityVisible() {
    boolean vis = false;
vis = vis | (main.mostCurrent != null);
vis = vis | (actsettings.mostCurrent != null);
vis = vis | (actabout.mostCurrent != null);
return vis;}
public static String  _activity_create(boolean _firsttime) throws Exception{
anywheresoftware.b4j.object.JavaObject _j1 = null;
anywheresoftware.b4j.object.JavaObject _j2 = null;
anywheresoftware.b4j.object.JavaObject _j3 = null;
anywheresoftware.b4j.object.JavaObject _j4 = null;
 //BA.debugLineNum = 81;BA.debugLine="Sub Activity_Create(FirstTime As Boolean)";
 //BA.debugLineNum = 82;BA.debugLine="If File.Exists(File.DirInternal, \"first.txt\") The";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"first.txt")) { 
 //BA.debugLineNum = 83;BA.debugLine="If File.Exists(File.DirInternal, \"light.txt\") Th";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"light.txt")) { 
 //BA.debugLineNum = 84;BA.debugLine="Activity.LoadLayout(\"MainLayoutLight\")";
mostCurrent._activity.LoadLayout("MainLayoutLight",mostCurrent.activityBA);
 //BA.debugLineNum = 85;BA.debugLine="theme = 0";
_theme = (int) (0);
 }else {
 //BA.debugLineNum = 87;BA.debugLine="Activity.LoadLayout(\"MainLayout\")";
mostCurrent._activity.LoadLayout("MainLayout",mostCurrent.activityBA);
 //BA.debugLineNum = 88;BA.debugLine="theme = 1";
_theme = (int) (1);
 };
 //BA.debugLineNum = 91;BA.debugLine="If File.Exists(File.DirInternal, \"english.txt\")";
if (anywheresoftware.b4a.keywords.Common.File.Exists(anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"english.txt")) { 
 //BA.debugLineNum = 92;BA.debugLine="toEnglish";
_toenglish();
 //BA.debugLineNum = 93;BA.debugLine="language = \"EN\"";
_language = "EN";
 }else {
 //BA.debugLineNum = 95;BA.debugLine="toPersion";
_topersion();
 //BA.debugLineNum = 96;BA.debugLine="language = \"Fa\"";
_language = "Fa";
 };
 }else {
 //BA.debugLineNum = 99;BA.debugLine="File.Copy(File.DirAssets, \"light.txt\", File.DirI";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"light.txt",anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"light.txt");
 //BA.debugLineNum = 100;BA.debugLine="File.Copy(File.DirAssets, \"first.txt\", File.DirI";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"first.txt",anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"first.txt");
 //BA.debugLineNum = 101;BA.debugLine="File.Copy(File.DirAssets, \"english.txt\", File.Di";
anywheresoftware.b4a.keywords.Common.File.Copy(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"english.txt",anywheresoftware.b4a.keywords.Common.File.getDirInternal(),"english.txt");
 //BA.debugLineNum = 102;BA.debugLine="toEnglish";
_toenglish();
 //BA.debugLineNum = 103;BA.debugLine="language = \"EN\"";
_language = "EN";
 };
 //BA.debugLineNum = 106;BA.debugLine="btnDisconnect.Enabled = False";
mostCurrent._btndisconnect.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 107;BA.debugLine="btnUp.Enabled = False";
mostCurrent._btnup.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 108;BA.debugLine="btnLeft.Enabled = False";
mostCurrent._btnleft.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 109;BA.debugLine="btnRight.Enabled = False";
mostCurrent._btnright.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 110;BA.debugLine="btnDown.Enabled = False";
mostCurrent._btndown.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 111;BA.debugLine="btnSmartMove.Enabled = False";
mostCurrent._btnsmartmove.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 112;BA.debugLine="btnLomp1.Enabled = False";
mostCurrent._btnlomp1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 113;BA.debugLine="btnSpeaker.Enabled = False";
mostCurrent._btnspeaker.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 114;BA.debugLine="btnConnect.Enabled = True";
mostCurrent._btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 115;BA.debugLine="isConnect = False";
_isconnect = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 117;BA.debugLine="Dim j1 As JavaObject";
_j1 = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 118;BA.debugLine="Dim j2 As JavaObject";
_j2 = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 119;BA.debugLine="Dim j3 As JavaObject";
_j3 = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 120;BA.debugLine="Dim j4 As JavaObject";
_j4 = new anywheresoftware.b4j.object.JavaObject();
 //BA.debugLineNum = 121;BA.debugLine="j1.InitializeContext";
_j1.InitializeContext(processBA);
 //BA.debugLineNum = 122;BA.debugLine="j2.InitializeContext";
_j2.InitializeContext(processBA);
 //BA.debugLineNum = 123;BA.debugLine="j3.InitializeContext";
_j3.InitializeContext(processBA);
 //BA.debugLineNum = 124;BA.debugLine="j4.InitializeContext";
_j4.InitializeContext(processBA);
 //BA.debugLineNum = 125;BA.debugLine="j1.RunMethod(\"MakeEvent\",Array As Object(btnUp,\"b";
_j1.RunMethod("MakeEvent",new Object[]{(Object)(mostCurrent._btnup.getObject()),(Object)("btn0_down"),(Object)("btn0_up")});
 //BA.debugLineNum = 126;BA.debugLine="j2.RunMethod(\"MakeEvent\",Array As Object(btnDown,";
_j2.RunMethod("MakeEvent",new Object[]{(Object)(mostCurrent._btndown.getObject()),(Object)("btn1_down"),(Object)("btn1_up")});
 //BA.debugLineNum = 127;BA.debugLine="j3.RunMethod(\"MakeEvent\",Array As Object(btnLeft,";
_j3.RunMethod("MakeEvent",new Object[]{(Object)(mostCurrent._btnleft.getObject()),(Object)("btn2_down"),(Object)("btn2_up")});
 //BA.debugLineNum = 128;BA.debugLine="j4.RunMethod(\"MakeEvent\",Array As Object(btnRight";
_j4.RunMethod("MakeEvent",new Object[]{(Object)(mostCurrent._btnright.getObject()),(Object)("btn3_down"),(Object)("btn3_up")});
 //BA.debugLineNum = 130;BA.debugLine="sbSpead.Value = 80";
mostCurrent._sbspead.setValue((int) (80));
 //BA.debugLineNum = 131;BA.debugLine="etSpead.Text = \"80\"";
mostCurrent._etspead.setText(BA.ObjectToCharSequence("80"));
 //BA.debugLineNum = 133;BA.debugLine="serial1.Initialize(\"Serial1\")";
_serial1.Initialize("Serial1");
 //BA.debugLineNum = 134;BA.debugLine="If serial1.IsEnabled = False Then";
if (_serial1.IsEnabled()==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 135;BA.debugLine="Msgbox(str_check_blue, str_check_blue_title)";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence(_str_check_blue),BA.ObjectToCharSequence(_str_check_blue_title),mostCurrent.activityBA);
 };
 //BA.debugLineNum = 147;BA.debugLine="monitor.Initialize(\"monitoring1\",10)";
_monitor.Initialize(processBA,"monitoring1",(long) (10));
 //BA.debugLineNum = 149;BA.debugLine="btnBar.Height = 0%y";
mostCurrent._btnbar.setHeight(anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (0),mostCurrent.activityBA));
 //BA.debugLineNum = 150;BA.debugLine="End Sub";
return "";
}
public static String  _activity_pause(boolean _userclosed) throws Exception{
 //BA.debugLineNum = 216;BA.debugLine="Sub Activity_Pause (UserClosed As Boolean)";
 //BA.debugLineNum = 218;BA.debugLine="End Sub";
return "";
}
public static String  _activity_resume() throws Exception{
 //BA.debugLineNum = 212;BA.debugLine="Sub Activity_Resume";
 //BA.debugLineNum = 213;BA.debugLine="serial1.Listen";
_serial1.Listen(processBA);
 //BA.debugLineNum = 214;BA.debugLine="End Sub";
return "";
}
public static String  _btn0_down() throws Exception{
 //BA.debugLineNum = 395;BA.debugLine="Sub btn0_down";
 //BA.debugLineNum = 396;BA.debugLine="tw.WriteLine(\"m\") ' mv --> move mode";
_tw.WriteLine("m");
 //BA.debugLineNum = 397;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 398;BA.debugLine="tw.WriteLine(pwm & \",0\") ' 0 --> forward";
_tw.WriteLine(mostCurrent._pwm+",0");
 //BA.debugLineNum = 399;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 403;BA.debugLine="End Sub";
return "";
}
public static String  _btn0_up() throws Exception{
 //BA.debugLineNum = 404;BA.debugLine="Sub btn0_up";
 //BA.debugLineNum = 405;BA.debugLine="tw.WriteLine(\"e\") ' end move final";
_tw.WriteLine("e");
 //BA.debugLineNum = 406;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 410;BA.debugLine="End Sub";
return "";
}
public static String  _btn1_down() throws Exception{
 //BA.debugLineNum = 416;BA.debugLine="Sub btn1_down";
 //BA.debugLineNum = 417;BA.debugLine="tw.WriteLine(\"m\") 'mv --> move mode";
_tw.WriteLine("m");
 //BA.debugLineNum = 418;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 419;BA.debugLine="tw.WriteLine(pwm & \",1\") ' 1 --> back";
_tw.WriteLine(mostCurrent._pwm+",1");
 //BA.debugLineNum = 420;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 424;BA.debugLine="End Sub";
return "";
}
public static String  _btn1_up() throws Exception{
 //BA.debugLineNum = 425;BA.debugLine="Sub btn1_up";
 //BA.debugLineNum = 426;BA.debugLine="tw.WriteLine(\"e\") ' end move final";
_tw.WriteLine("e");
 //BA.debugLineNum = 427;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 431;BA.debugLine="End Sub";
return "";
}
public static String  _btn2_down() throws Exception{
 //BA.debugLineNum = 437;BA.debugLine="Sub btn2_down";
 //BA.debugLineNum = 438;BA.debugLine="tw.WriteLine(\"m\") 'mv --> move mode";
_tw.WriteLine("m");
 //BA.debugLineNum = 439;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 440;BA.debugLine="tw.WriteLine(pwm & \",2\") ' 2 --> left";
_tw.WriteLine(mostCurrent._pwm+",2");
 //BA.debugLineNum = 441;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 445;BA.debugLine="End Sub";
return "";
}
public static String  _btn2_up() throws Exception{
 //BA.debugLineNum = 446;BA.debugLine="Sub btn2_up";
 //BA.debugLineNum = 447;BA.debugLine="tw.WriteLine(\"e\") ' end move final";
_tw.WriteLine("e");
 //BA.debugLineNum = 448;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 452;BA.debugLine="End Sub";
return "";
}
public static String  _btn3_down() throws Exception{
 //BA.debugLineNum = 459;BA.debugLine="Sub btn3_down";
 //BA.debugLineNum = 460;BA.debugLine="tw.WriteLine(\"m\") 'mv --> move mode";
_tw.WriteLine("m");
 //BA.debugLineNum = 461;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 462;BA.debugLine="tw.WriteLine(pwm & \",3\") ' 3 --> right";
_tw.WriteLine(mostCurrent._pwm+",3");
 //BA.debugLineNum = 463;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 467;BA.debugLine="End Sub";
return "";
}
public static String  _btn3_up() throws Exception{
 //BA.debugLineNum = 468;BA.debugLine="Sub btn3_up";
 //BA.debugLineNum = 469;BA.debugLine="tw.WriteLine(\"e\") ' end move final";
_tw.WriteLine("e");
 //BA.debugLineNum = 470;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 474;BA.debugLine="End Sub";
return "";
}
public static String  _btnconnect_click() throws Exception{
anywheresoftware.b4a.objects.collections.Map _map1 = null;
anywheresoftware.b4a.objects.collections.List _ls = null;
int _i = 0;
int _result_index = 0;
 //BA.debugLineNum = 282;BA.debugLine="Sub btnConnect_Click";
 //BA.debugLineNum = 283;BA.debugLine="Dim map1 As Map";
_map1 = new anywheresoftware.b4a.objects.collections.Map();
 //BA.debugLineNum = 284;BA.debugLine="Dim ls As List";
_ls = new anywheresoftware.b4a.objects.collections.List();
 //BA.debugLineNum = 285;BA.debugLine="map1.Initialize";
_map1.Initialize();
 //BA.debugLineNum = 286;BA.debugLine="ls.Initialize";
_ls.Initialize();
 //BA.debugLineNum = 287;BA.debugLine="map1 = serial1.GetPairedDevices";
_map1 = _serial1.GetPairedDevices();
 //BA.debugLineNum = 288;BA.debugLine="For i = 0 To map1.Size-1";
{
final int step6 = 1;
final int limit6 = (int) (_map1.getSize()-1);
_i = (int) (0) ;
for (;_i <= limit6 ;_i = _i + step6 ) {
 //BA.debugLineNum = 289;BA.debugLine="ls.Add(map1.GetKeyAt(i))";
_ls.Add(_map1.GetKeyAt(_i));
 }
};
 //BA.debugLineNum = 291;BA.debugLine="Dim result_index As Int";
_result_index = 0;
 //BA.debugLineNum = 292;BA.debugLine="result_index = InputList(ls,str_connect_toBlue,-1";
_result_index = anywheresoftware.b4a.keywords.Common.InputList(_ls,BA.ObjectToCharSequence(_str_connect_toblue),(int) (-1),mostCurrent.activityBA);
 //BA.debugLineNum = 293;BA.debugLine="serial1.Connect(map1.Get(ls.Get(result_index)))";
_serial1.Connect(processBA,BA.ObjectToString(_map1.Get(_ls.Get(_result_index))));
 //BA.debugLineNum = 294;BA.debugLine="End Sub";
return "";
}
public static String  _btndisconnect_click() throws Exception{
 //BA.debugLineNum = 296;BA.debugLine="Sub btnDisconnect_Click";
 //BA.debugLineNum = 297;BA.debugLine="monitor.Enabled = False";
_monitor.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 298;BA.debugLine="tw.WriteLine(\"d\") 'send disconnect to robot";
_tw.WriteLine("d");
 //BA.debugLineNum = 299;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 302;BA.debugLine="btnBar.Height = 0%y";
mostCurrent._btnbar.setHeight(anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (0),mostCurrent.activityBA));
 //BA.debugLineNum = 303;BA.debugLine="lblTemp.Text = \"__ ^c\"";
mostCurrent._lbltemp.setText(BA.ObjectToCharSequence("__ ^c"));
 //BA.debugLineNum = 304;BA.debugLine="lblDistance.Text = \"___ cm\"";
mostCurrent._lbldistance.setText(BA.ObjectToCharSequence("___ cm"));
 //BA.debugLineNum = 305;BA.debugLine="sbSpead.Value = 80";
mostCurrent._sbspead.setValue((int) (80));
 //BA.debugLineNum = 306;BA.debugLine="etSpead.Text = \"80\"";
mostCurrent._etspead.setText(BA.ObjectToCharSequence("80"));
 //BA.debugLineNum = 309;BA.debugLine="serial1.Disconnect";
_serial1.Disconnect();
 //BA.debugLineNum = 310;BA.debugLine="isConnect = False";
_isconnect = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 311;BA.debugLine="btnDisconnect.Enabled = False";
mostCurrent._btndisconnect.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 312;BA.debugLine="btnUp.Enabled = False";
mostCurrent._btnup.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 313;BA.debugLine="btnLeft.Enabled = False";
mostCurrent._btnleft.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 314;BA.debugLine="btnRight.Enabled = False";
mostCurrent._btnright.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 315;BA.debugLine="btnDown.Enabled = False";
mostCurrent._btndown.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 316;BA.debugLine="btnSmartMove.Enabled = False";
mostCurrent._btnsmartmove.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 317;BA.debugLine="btnLomp1.Enabled = False";
mostCurrent._btnlomp1.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 318;BA.debugLine="btnSpeaker.Enabled = False";
mostCurrent._btnspeaker.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 319;BA.debugLine="btnConnect.Enabled = True";
mostCurrent._btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 320;BA.debugLine="ToastMessageShow(str_msg_disconnect,True)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence(_str_msg_disconnect),anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 321;BA.debugLine="End Sub";
return "";
}
public static String  _btnlomp1_click() throws Exception{
 //BA.debugLineNum = 349;BA.debugLine="Sub btnLomp1_Click";
 //BA.debugLineNum = 350;BA.debugLine="If IsOnLomp = False Then";
if (_isonlomp==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 351;BA.debugLine="tw.WriteLine(\"o\") ' lomp was off and is on now";
_tw.WriteLine("o");
 //BA.debugLineNum = 352;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 353;BA.debugLine="btnLomp1.SetBackgroundImage(LoadBitmap(File.DirA";
mostCurrent._btnlomp1.SetBackgroundImageNew((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"on.png").getObject()));
 //BA.debugLineNum = 354;BA.debugLine="IsOnLomp = True";
_isonlomp = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 356;BA.debugLine="tw.WriteLine(\"f\") ' lomp was on and is off now";
_tw.WriteLine("f");
 //BA.debugLineNum = 357;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 358;BA.debugLine="btnLomp1.SetBackgroundImage(LoadBitmap(File.DirA";
mostCurrent._btnlomp1.SetBackgroundImageNew((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"off.png").getObject()));
 //BA.debugLineNum = 359;BA.debugLine="IsOnLomp = False";
_isonlomp = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 361;BA.debugLine="End Sub";
return "";
}
public static String  _btnsettings_click() throws Exception{
 //BA.debugLineNum = 270;BA.debugLine="Sub btnSettings_Click";
 //BA.debugLineNum = 271;BA.debugLine="monitor.Enabled = False";
_monitor.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 272;BA.debugLine="If isConnect = True Then";
if (_isconnect==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 273;BA.debugLine="tw.WriteLine(\"d\") 'send disconnect to robot";
_tw.WriteLine("d");
 //BA.debugLineNum = 274;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 275;BA.debugLine="serial1.Disconnect";
_serial1.Disconnect();
 //BA.debugLineNum = 276;BA.debugLine="isConnect = False";
_isconnect = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 278;BA.debugLine="Activity.Finish";
mostCurrent._activity.Finish();
 //BA.debugLineNum = 279;BA.debugLine="StartActivity(actSettings)";
anywheresoftware.b4a.keywords.Common.StartActivity(processBA,(Object)(mostCurrent._actsettings.getObject()));
 //BA.debugLineNum = 280;BA.debugLine="End Sub";
return "";
}
public static String  _btnsmartmove_click() throws Exception{
 //BA.debugLineNum = 363;BA.debugLine="Sub btnSmartMove_Click";
 //BA.debugLineNum = 364;BA.debugLine="If IsOnSMS = False Then";
if (_isonsms==anywheresoftware.b4a.keywords.Common.False) { 
 //BA.debugLineNum = 365;BA.debugLine="tw.WriteLine(\"s\") ' smart move start";
_tw.WriteLine("s");
 //BA.debugLineNum = 366;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 368;BA.debugLine="btnSmartMove.SetBackgroundImage(LoadBitmap(File.";
mostCurrent._btnsmartmove.SetBackgroundImageNew((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"smsOff.png").getObject()));
 //BA.debugLineNum = 369;BA.debugLine="If language = \"EN\" Then";
if ((_language).equals("EN")) { 
 //BA.debugLineNum = 370;BA.debugLine="btnSmartMove.Text = \"Stop smart move\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("Stop smart move"));
 }else {
 //BA.debugLineNum = 372;BA.debugLine="btnSmartMove.Text = \"توقف حرکت هوشمند\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("توقف حرکت هوشمند"));
 };
 //BA.debugLineNum = 374;BA.debugLine="IsOnSMS = True";
_isonsms = anywheresoftware.b4a.keywords.Common.True;
 }else {
 //BA.debugLineNum = 376;BA.debugLine="tw.WriteLine(\"e\") ' smart move final";
_tw.WriteLine("e");
 //BA.debugLineNum = 377;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 379;BA.debugLine="btnSmartMove.SetBackgroundImage(LoadBitmap(File.";
mostCurrent._btnsmartmove.SetBackgroundImageNew((android.graphics.Bitmap)(anywheresoftware.b4a.keywords.Common.LoadBitmap(anywheresoftware.b4a.keywords.Common.File.getDirAssets(),"smsOn.png").getObject()));
 //BA.debugLineNum = 380;BA.debugLine="If language = \"EN\" Then";
if ((_language).equals("EN")) { 
 //BA.debugLineNum = 381;BA.debugLine="btnSmartMove.Text = \"Start smart move\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("Start smart move"));
 }else {
 //BA.debugLineNum = 383;BA.debugLine="btnSmartMove.Text = \"شروع حرکت هوشمند\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("شروع حرکت هوشمند"));
 };
 //BA.debugLineNum = 385;BA.debugLine="IsOnSMS = False";
_isonsms = anywheresoftware.b4a.keywords.Common.False;
 };
 //BA.debugLineNum = 387;BA.debugLine="End Sub";
return "";
}
public static String  _btnspeaker_click() throws Exception{
 //BA.debugLineNum = 389;BA.debugLine="Sub btnSpeaker_Click";
 //BA.debugLineNum = 390;BA.debugLine="tw.WriteLine(\"b\")";
_tw.WriteLine("b");
 //BA.debugLineNum = 391;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 392;BA.debugLine="End Sub";
return "";
}
public static String  _etspead_enterpressed() throws Exception{
 //BA.debugLineNum = 491;BA.debugLine="Sub etSpead_EnterPressed";
 //BA.debugLineNum = 492;BA.debugLine="If etSpead.Text = \"\" Then";
if ((mostCurrent._etspead.getText()).equals("")) { 
 //BA.debugLineNum = 493;BA.debugLine="etSpead.Text = sbSpead.Value";
mostCurrent._etspead.setText(BA.ObjectToCharSequence(mostCurrent._sbspead.getValue()));
 }else if((double)(Double.parseDouble(mostCurrent._etspead.getText()))<101) { 
 //BA.debugLineNum = 496;BA.debugLine="pwm = etSpead.Text";
mostCurrent._pwm = mostCurrent._etspead.getText();
 //BA.debugLineNum = 497;BA.debugLine="sbSpead.Value = etSpead.Text";
mostCurrent._sbspead.setValue((int)(Double.parseDouble(mostCurrent._etspead.getText())));
 }else {
 //BA.debugLineNum = 499;BA.debugLine="etSpead.Text = \"100\"";
mostCurrent._etspead.setText(BA.ObjectToCharSequence("100"));
 //BA.debugLineNum = 500;BA.debugLine="pwm = 100";
mostCurrent._pwm = BA.NumberToString(100);
 //BA.debugLineNum = 501;BA.debugLine="sbSpead.Value = 100";
mostCurrent._sbspead.setValue((int) (100));
 //BA.debugLineNum = 502;BA.debugLine="ToastMessageShow(str_error_overflow_speed,False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence(_str_error_overflow_speed),anywheresoftware.b4a.keywords.Common.False);
 };
 //BA.debugLineNum = 504;BA.debugLine="End Sub";
return "";
}
public static String  _globals() throws Exception{
 //BA.debugLineNum = 50;BA.debugLine="Sub Globals";
 //BA.debugLineNum = 51;BA.debugLine="Private btnSettings As Button";
mostCurrent._btnsettings = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 52;BA.debugLine="Private btnConnect As Button";
mostCurrent._btnconnect = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 53;BA.debugLine="Private btnDisconnect As Button";
mostCurrent._btndisconnect = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 54;BA.debugLine="Private btnBar As Button";
mostCurrent._btnbar = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 55;BA.debugLine="Private lblDistanceTxt As Label";
mostCurrent._lbldistancetxt = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 56;BA.debugLine="Private lblDistance As Label";
mostCurrent._lbldistance = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 57;BA.debugLine="Private etSpead As EditText";
mostCurrent._etspead = new anywheresoftware.b4a.objects.EditTextWrapper();
 //BA.debugLineNum = 58;BA.debugLine="Private sbSpead As SeekBar";
mostCurrent._sbspead = new anywheresoftware.b4a.objects.SeekBarWrapper();
 //BA.debugLineNum = 59;BA.debugLine="Private lblTemp As Label";
mostCurrent._lbltemp = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 60;BA.debugLine="Private btnSpeaker As Button";
mostCurrent._btnspeaker = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 61;BA.debugLine="Private btnUp As Button";
mostCurrent._btnup = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 62;BA.debugLine="Private btnLeft As Button";
mostCurrent._btnleft = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 63;BA.debugLine="Private btnRight As Button";
mostCurrent._btnright = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 64;BA.debugLine="Private btnDown As Button";
mostCurrent._btndown = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 65;BA.debugLine="Private btnSmartMove As Button";
mostCurrent._btnsmartmove = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 66;BA.debugLine="Private btnLomp1 As Button";
mostCurrent._btnlomp1 = new anywheresoftware.b4a.objects.ButtonWrapper();
 //BA.debugLineNum = 67;BA.debugLine="Private lblTxtSpeed As Label";
mostCurrent._lbltxtspeed = new anywheresoftware.b4a.objects.LabelWrapper();
 //BA.debugLineNum = 70;BA.debugLine="Dim pwm As String: pwm = \"80\"";
mostCurrent._pwm = "";
 //BA.debugLineNum = 70;BA.debugLine="Dim pwm As String: pwm = \"80\"";
mostCurrent._pwm = "80";
 //BA.debugLineNum = 72;BA.debugLine="Dim IsOnLomp As Boolean: IsOnLomp = False ' flag";
_isonlomp = false;
 //BA.debugLineNum = 72;BA.debugLine="Dim IsOnLomp As Boolean: IsOnLomp = False ' flag";
_isonlomp = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 73;BA.debugLine="Dim IsOnSMS As Boolean: IsOnSMS = False   ' flag";
_isonsms = false;
 //BA.debugLineNum = 73;BA.debugLine="Dim IsOnSMS As Boolean: IsOnSMS = False   ' flag";
_isonsms = anywheresoftware.b4a.keywords.Common.False;
 //BA.debugLineNum = 75;BA.debugLine="Dim temp As Int";
_temp = 0;
 //BA.debugLineNum = 76;BA.debugLine="Dim distance As Int";
_distance = 0;
 //BA.debugLineNum = 78;BA.debugLine="Dim isConnect As Boolean";
_isconnect = false;
 //BA.debugLineNum = 79;BA.debugLine="End Sub";
return "";
}
public static String  _monitoring1_tick() throws Exception{
 //BA.debugLineNum = 152;BA.debugLine="Sub monitoring1_Tick";
 //BA.debugLineNum = 153;BA.debugLine="If tr.Ready = True Then";
if (_tr.Ready()==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 154;BA.debugLine="temp = tr.ReadLine";
_temp = (int)(Double.parseDouble(_tr.ReadLine()));
 //BA.debugLineNum = 155;BA.debugLine="distance = tr.ReadLine";
_distance = (int)(Double.parseDouble(_tr.ReadLine()));
 //BA.debugLineNum = 156;BA.debugLine="lblTemp.Text = temp";
mostCurrent._lbltemp.setText(BA.ObjectToCharSequence(_temp));
 //BA.debugLineNum = 160;BA.debugLine="temp = temp  * 1%y";
_temp = (int) (_temp*anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (1),mostCurrent.activityBA));
 //BA.debugLineNum = 161;BA.debugLine="btnBar.Height = (temp * 30%y)/50%y";
mostCurrent._btnbar.setHeight((int) ((_temp*anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (30),mostCurrent.activityBA))/(double)anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (50),mostCurrent.activityBA)));
 //BA.debugLineNum = 162;BA.debugLine="btnBar.Top = 35%y - btnBar.Height";
mostCurrent._btnbar.setTop((int) (anywheresoftware.b4a.keywords.Common.PerYToCurrent((float) (35),mostCurrent.activityBA)-mostCurrent._btnbar.getHeight()));
 //BA.debugLineNum = 163;BA.debugLine="lblTemp.Text = lblTemp.Text & \" ^c\"";
mostCurrent._lbltemp.setText(BA.ObjectToCharSequence(mostCurrent._lbltemp.getText()+" ^c"));
 //BA.debugLineNum = 165;BA.debugLine="lblDistance.Text = distance";
mostCurrent._lbldistance.setText(BA.ObjectToCharSequence(_distance));
 //BA.debugLineNum = 166;BA.debugLine="lblDistance.Text = lblDistance.Text & \" cm\"";
mostCurrent._lbldistance.setText(BA.ObjectToCharSequence(mostCurrent._lbldistance.getText()+" cm"));
 };
 //BA.debugLineNum = 168;BA.debugLine="End Sub";
return "";
}

public static void initializeProcessGlobals() {
    
    if (main.processGlobalsRun == false) {
	    main.processGlobalsRun = true;
		try {
		        main._process_globals();
actsettings._process_globals();
starter._process_globals();
actabout._process_globals();
		
        } catch (Exception e) {
			throw new RuntimeException(e);
		}
    }
}public static String  _process_globals() throws Exception{
 //BA.debugLineNum = 15;BA.debugLine="Sub Process_Globals";
 //BA.debugLineNum = 16;BA.debugLine="Dim serial1 As Serial";
_serial1 = new anywheresoftware.b4a.objects.Serial();
 //BA.debugLineNum = 17;BA.debugLine="Dim tw As TextWriter";
_tw = new anywheresoftware.b4a.objects.streams.File.TextWriterWrapper();
 //BA.debugLineNum = 18;BA.debugLine="Dim tr As TextReader";
_tr = new anywheresoftware.b4a.objects.streams.File.TextReaderWrapper();
 //BA.debugLineNum = 24;BA.debugLine="Dim monitor As Timer";
_monitor = new anywheresoftware.b4a.objects.Timer();
 //BA.debugLineNum = 28;BA.debugLine="Dim language As String";
_language = "";
 //BA.debugLineNum = 29;BA.debugLine="Dim theme As Int";
_theme = 0;
 //BA.debugLineNum = 31;BA.debugLine="Dim str_check_blue As String";
_str_check_blue = "";
 //BA.debugLineNum = 32;BA.debugLine="Dim str_check_blue_title As String";
_str_check_blue_title = "";
 //BA.debugLineNum = 33;BA.debugLine="Dim str_connect_toBlue As String";
_str_connect_toblue = "";
 //BA.debugLineNum = 34;BA.debugLine="Dim str_msg_disconnect As String";
_str_msg_disconnect = "";
 //BA.debugLineNum = 35;BA.debugLine="Dim str_msg_connected As String";
_str_msg_connected = "";
 //BA.debugLineNum = 36;BA.debugLine="Dim str_msg_erorrInConnect As String";
_str_msg_erorrinconnect = "";
 //BA.debugLineNum = 37;BA.debugLine="Dim str_title_erorrInConnect As String";
_str_title_erorrinconnect = "";
 //BA.debugLineNum = 38;BA.debugLine="Dim flag_stop_start_smartMove As Boolean: flag_st";
_flag_stop_start_smartmove = false;
 //BA.debugLineNum = 38;BA.debugLine="Dim flag_stop_start_smartMove As Boolean: flag_st";
_flag_stop_start_smartmove = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 39;BA.debugLine="Dim str_txt_settings As String";
_str_txt_settings = "";
 //BA.debugLineNum = 40;BA.debugLine="Dim str_txt_about As String";
_str_txt_about = "";
 //BA.debugLineNum = 46;BA.debugLine="Dim str_error_overflow_speed As String";
_str_error_overflow_speed = "";
 //BA.debugLineNum = 48;BA.debugLine="End Sub";
return "";
}
public static String  _sbspead_valuechanged(int _value,boolean _userchanged) throws Exception{
 //BA.debugLineNum = 481;BA.debugLine="Sub sbSpead_ValueChanged (Value As Int, UserChange";
 //BA.debugLineNum = 482;BA.debugLine="pwm = Value";
mostCurrent._pwm = BA.NumberToString(_value);
 //BA.debugLineNum = 483;BA.debugLine="etSpead.Text = Value";
mostCurrent._etspead.setText(BA.ObjectToCharSequence(_value));
 //BA.debugLineNum = 484;BA.debugLine="End Sub";
return "";
}
public static String  _serial1_connected(boolean _success) throws Exception{
 //BA.debugLineNum = 323;BA.debugLine="Sub serial1_Connected (Success As Boolean)";
 //BA.debugLineNum = 324;BA.debugLine="If Success = True Then";
if (_success==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 325;BA.debugLine="tw.Initialize(serial1.OutputStream)";
_tw.Initialize(_serial1.getOutputStream());
 //BA.debugLineNum = 326;BA.debugLine="tr.Initialize(serial1.InputStream)";
_tr.Initialize(_serial1.getInputStream());
 //BA.debugLineNum = 327;BA.debugLine="tw.WriteLine(\"c\") 'send to robot connected flag";
_tw.WriteLine("c");
 //BA.debugLineNum = 328;BA.debugLine="tw.Flush";
_tw.Flush();
 //BA.debugLineNum = 330;BA.debugLine="isConnect = True";
_isconnect = anywheresoftware.b4a.keywords.Common.True;
 //BA.debugLineNum = 331;BA.debugLine="ToastMessageShow(str_msg_connected,False)";
anywheresoftware.b4a.keywords.Common.ToastMessageShow(BA.ObjectToCharSequence(_str_msg_connected),anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 333;BA.debugLine="btnDisconnect.Enabled = True";
mostCurrent._btndisconnect.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 334;BA.debugLine="btnUp.Enabled = True";
mostCurrent._btnup.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 335;BA.debugLine="btnLeft.Enabled = True";
mostCurrent._btnleft.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 336;BA.debugLine="btnRight.Enabled = True";
mostCurrent._btnright.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 337;BA.debugLine="btnDown.Enabled = True";
mostCurrent._btndown.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 338;BA.debugLine="btnSmartMove.Enabled = True";
mostCurrent._btnsmartmove.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 339;BA.debugLine="btnLomp1.Enabled = True";
mostCurrent._btnlomp1.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 340;BA.debugLine="btnSpeaker.Enabled = True";
mostCurrent._btnspeaker.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 //BA.debugLineNum = 341;BA.debugLine="btnConnect.Enabled = False";
mostCurrent._btnconnect.setEnabled(anywheresoftware.b4a.keywords.Common.False);
 //BA.debugLineNum = 343;BA.debugLine="monitor.Enabled = True";
_monitor.setEnabled(anywheresoftware.b4a.keywords.Common.True);
 }else {
 //BA.debugLineNum = 345;BA.debugLine="Msgbox(str_msg_erorrInConnect, str_title_erorrIn";
anywheresoftware.b4a.keywords.Common.Msgbox(BA.ObjectToCharSequence(_str_msg_erorrinconnect),BA.ObjectToCharSequence(_str_title_erorrinconnect),mostCurrent.activityBA);
 };
 //BA.debugLineNum = 347;BA.debugLine="End Sub";
return "";
}
public static String  _toenglish() throws Exception{
 //BA.debugLineNum = 245;BA.debugLine="Sub toEnglish";
 //BA.debugLineNum = 246;BA.debugLine="lblDistanceTxt.Text = \"Distance\"";
mostCurrent._lbldistancetxt.setText(BA.ObjectToCharSequence("Distance"));
 //BA.debugLineNum = 247;BA.debugLine="lblTxtSpeed.Text = \"Speed:\"";
mostCurrent._lbltxtspeed.setText(BA.ObjectToCharSequence("Speed:"));
 //BA.debugLineNum = 248;BA.debugLine="If flag_stop_start_smartMove = True Then";
if (_flag_stop_start_smartmove==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 249;BA.debugLine="btnSmartMove.Text = \"Start smart move\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("Start smart move"));
 }else {
 //BA.debugLineNum = 251;BA.debugLine="btnSmartMove.Text = \"Stop smart move\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("Stop smart move"));
 };
 //BA.debugLineNum = 254;BA.debugLine="str_check_blue = \"Please turn on Bluetooth and Tr";
_str_check_blue = "Please turn on Bluetooth and Try again";
 //BA.debugLineNum = 255;BA.debugLine="str_check_blue_title = \"Bluetooth is off!!\"";
_str_check_blue_title = "Bluetooth is off!!";
 //BA.debugLineNum = 256;BA.debugLine="str_connect_toBlue = \"Connect to ...\"";
_str_connect_toblue = "Connect to ...";
 //BA.debugLineNum = 257;BA.debugLine="str_msg_disconnect = \"Disconnected\"";
_str_msg_disconnect = "Disconnected";
 //BA.debugLineNum = 258;BA.debugLine="str_msg_connected = \"Connected\"";
_str_msg_connected = "Connected";
 //BA.debugLineNum = 259;BA.debugLine="str_msg_erorrInConnect = \"Please try again...\"";
_str_msg_erorrinconnect = "Please try again...";
 //BA.debugLineNum = 260;BA.debugLine="str_title_erorrInConnect = \"Error in connect\"";
_str_title_erorrinconnect = "Error in connect";
 //BA.debugLineNum = 261;BA.debugLine="str_txt_settings = \"               Settings\"";
_str_txt_settings = "               Settings";
 //BA.debugLineNum = 262;BA.debugLine="str_txt_about = \"          About\"";
_str_txt_about = "          About";
 //BA.debugLineNum = 267;BA.debugLine="str_error_overflow_speed = \"Speed must be between";
_str_error_overflow_speed = "Speed must be between 0 and 100";
 //BA.debugLineNum = 268;BA.debugLine="End Sub";
return "";
}
public static String  _topersion() throws Exception{
 //BA.debugLineNum = 220;BA.debugLine="Sub toPersion";
 //BA.debugLineNum = 221;BA.debugLine="lblDistanceTxt.Text = \"فاصله:\"";
mostCurrent._lbldistancetxt.setText(BA.ObjectToCharSequence("فاصله:"));
 //BA.debugLineNum = 222;BA.debugLine="lblTxtSpeed.Text = \"سرعت:\"";
mostCurrent._lbltxtspeed.setText(BA.ObjectToCharSequence("سرعت:"));
 //BA.debugLineNum = 223;BA.debugLine="If flag_stop_start_smartMove = True Then";
if (_flag_stop_start_smartmove==anywheresoftware.b4a.keywords.Common.True) { 
 //BA.debugLineNum = 224;BA.debugLine="btnSmartMove.Text = \"شروع حرکت هوشمند\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("شروع حرکت هوشمند"));
 }else {
 //BA.debugLineNum = 226;BA.debugLine="btnSmartMove.Text = \"پایان حرکت هوشمند\"";
mostCurrent._btnsmartmove.setText(BA.ObjectToCharSequence("پایان حرکت هوشمند"));
 };
 //BA.debugLineNum = 229;BA.debugLine="str_check_blue = \"لطفا بلوتوث را روشن کنید و دوبا";
_str_check_blue = "لطفا بلوتوث را روشن کنید و دوباره امتحان کنید";
 //BA.debugLineNum = 230;BA.debugLine="str_check_blue_title = \"بلوتوث خاموش است!!\"";
_str_check_blue_title = "بلوتوث خاموش است!!";
 //BA.debugLineNum = 231;BA.debugLine="str_connect_toBlue = \"متصل شوید به ...\"";
_str_connect_toblue = "متصل شوید به ...";
 //BA.debugLineNum = 232;BA.debugLine="str_msg_disconnect = \"اتصال قطع شد!\"";
_str_msg_disconnect = "اتصال قطع شد!";
 //BA.debugLineNum = 233;BA.debugLine="str_msg_connected = \"متصل شد\"";
_str_msg_connected = "متصل شد";
 //BA.debugLineNum = 234;BA.debugLine="str_msg_erorrInConnect = \"لطفا دوباره امتحان کنید";
_str_msg_erorrinconnect = "لطفا دوباره امتحان کنید...";
 //BA.debugLineNum = 235;BA.debugLine="str_title_erorrInConnect = \"خطا در اتصال\"";
_str_title_erorrinconnect = "خطا در اتصال";
 //BA.debugLineNum = 236;BA.debugLine="str_txt_settings = \"تنظیمات             \"";
_str_txt_settings = "تنظیمات             ";
 //BA.debugLineNum = 237;BA.debugLine="str_txt_about = \"درباره ما            \"";
_str_txt_about = "درباره ما            ";
 //BA.debugLineNum = 242;BA.debugLine="str_error_overflow_speed = \"سرعت باید بین 0 تا 10";
_str_error_overflow_speed = "سرعت باید بین 0 تا 100 باشد!";
 //BA.debugLineNum = 243;BA.debugLine="End Sub";
return "";
}

	 public void MakeEvent(Button button,final String EventName,final String EventName2){
		 button.setOnTouchListener(new OnTouchListener() {
			
			@Override
			public boolean onTouch(View arg0, MotionEvent motionevent) {
			if(motionevent.getAction()==MotionEvent.ACTION_DOWN){
				processBA.raiseEventFromUI(this, EventName,null);}
				else if(motionevent.getAction()==MotionEvent.ACTION_UP){
				processBA.raiseEventFromUI(this, EventName2,null);}
				return false;
				//pejman nikravan
			}
		});
	 }
}

package com.DarkRobo.mmd.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_abuotlayout{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("lbltxtabout").vw.setTop((int)((0d / 100 * height)));
views.get("lbltxtabout").vw.setLeft((int)((0d / 100 * width)));
views.get("lbltxtabout").vw.setWidth((int)((100d / 100 * width)));
views.get("lbltxtabout").vw.setHeight((int)((9d / 100 * height)));
views.get("btnback").vw.setTop((int)((1d / 100 * height)));
views.get("btnback").vw.setLeft((int)((2d / 100 * width)));
views.get("btnback").vw.setWidth((int)((14d / 100 * width)));
views.get("btnback").vw.setHeight((int)((7d / 100 * height)));
views.get("imglogo").vw.setTop((int)((10d / 100 * height)));
views.get("imglogo").vw.setLeft((int)((18d / 100 * width)));
views.get("imglogo").vw.setWidth((int)((64d / 100 * width)));
views.get("imglogo").vw.setHeight((int)((30d / 100 * height)));
views.get("lbldescriptionapp").vw.setTop((int)((views.get("imglogo").vw.getTop() + views.get("imglogo").vw.getHeight())+(1d / 100 * height)));
views.get("lbldescriptionapp").vw.setLeft((int)((3d / 100 * width)));
views.get("lbldescriptionapp").vw.setWidth((int)((94d / 100 * width)));
views.get("lbldescriptionapp").vw.setHeight((int)((32d / 100 * height)));
views.get("lbldescriptionappen").vw.setTop((int)((views.get("lbldescriptionapp").vw.getTop())));
views.get("lbldescriptionappen").vw.setLeft((int)((views.get("lbldescriptionapp").vw.getLeft())));
views.get("lbldescriptionappen").vw.setWidth((int)((views.get("lbldescriptionapp").vw.getWidth())));
views.get("lbldescriptionappen").vw.setHeight((int)((views.get("lbldescriptionapp").vw.getHeight())));
views.get("lblhoghogh").vw.setTop((int)((views.get("lbldescriptionapp").vw.getTop() + views.get("lbldescriptionapp").vw.getHeight())+(1d / 100 * height)));
views.get("lblhoghogh").vw.setLeft((int)((1d / 100 * width)));
views.get("lblhoghogh").vw.setWidth((int)((98d / 100 * width)));
views.get("lblhoghogh").vw.setHeight((int)((7d / 100 * height)));
views.get("img_family").vw.setTop((int)((views.get("lblhoghogh").vw.getTop() + views.get("lblhoghogh").vw.getHeight())+(5d / 100 * height)));
views.get("img_family").vw.setLeft((int)((5d / 100 * width)));
views.get("img_family").vw.setWidth((int)((25d / 100 * width)));
views.get("img_family").vw.setHeight((int)((12d / 100 * height)));
views.get("img_marlik").vw.setTop((int)((views.get("img_family").vw.getTop())));
views.get("img_marlik").vw.setLeft((int)((views.get("img_family").vw.getLeft() + views.get("img_family").vw.getWidth())+(3d / 100 * width)));
views.get("img_marlik").vw.setWidth((int)((views.get("img_family").vw.getWidth())));
views.get("img_marlik").vw.setHeight((int)((views.get("img_family").vw.getHeight())));
views.get("lbltxthamis").vw.setTop((int)((views.get("img_family").vw.getTop())));
views.get("lbltxthamis").vw.setLeft((int)((views.get("img_marlik").vw.getLeft() + views.get("img_marlik").vw.getWidth())+(5d / 100 * width)));
views.get("lbltxthamis").vw.setWidth((int)((35d / 100 * width)));
//BA.debugLineNum = 47;BA.debugLine="lblTxtHamis.Height = 8%y"[AbuotLayout/General script]
views.get("lbltxthamis").vw.setHeight((int)((8d / 100 * height)));

}
}
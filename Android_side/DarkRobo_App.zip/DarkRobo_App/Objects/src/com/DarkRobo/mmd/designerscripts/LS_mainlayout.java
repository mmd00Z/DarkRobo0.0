package com.DarkRobo.mmd.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_mainlayout{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("btnbacktemp").vw.setHeight((int)((37.5d / 100 * height)));
views.get("btnbacktemp").vw.setWidth((int)((25d / 100 * width)));
views.get("btnbacktemp").vw.setTop((int)((39.5d / 100 * height) - (views.get("btnbacktemp").vw.getHeight())));
views.get("btnbacktemp").vw.setLeft((int)((72.5d / 100 * width)));
views.get("btnbar").vw.setHeight((int)((15d / 100 * height)));
views.get("btnbar").vw.setWidth((int)((2.5d / 100 * width)));
views.get("btnbar").vw.setTop((int)((35d / 100 * height)-(views.get("btnbar").vw.getHeight())));
views.get("btnbar").vw.setLeft((int)((83.75d / 100 * width)));
views.get("btnup").vw.setTop((int)((45d / 100 * height)));
views.get("btnup").vw.setLeft((int)((40d / 100 * width)));
views.get("btnup").vw.setWidth((int)((20d / 100 * width)));
views.get("btnup").vw.setHeight((int)((10d / 100 * height)));
views.get("btndown").vw.setTop((int)((65d / 100 * height)));
views.get("btndown").vw.setLeft((int)((40d / 100 * width)));
views.get("btndown").vw.setWidth((int)((20d / 100 * width)));
views.get("btndown").vw.setHeight((int)((10d / 100 * height)));
views.get("btnleft").vw.setTop((int)((55d / 100 * height)));
views.get("btnleft").vw.setLeft((int)((20d / 100 * width)));
views.get("btnleft").vw.setWidth((int)((20d / 100 * width)));
views.get("btnleft").vw.setHeight((int)((10d / 100 * height)));
views.get("btnright").vw.setTop((int)((55d / 100 * height)));
views.get("btnright").vw.setLeft((int)((60d / 100 * width)));
views.get("btnright").vw.setWidth((int)((20d / 100 * width)));
views.get("btnright").vw.setHeight((int)((10d / 100 * height)));
views.get("btnspeaker").vw.setTop((int)((views.get("btnup").vw.getTop() + views.get("btnup").vw.getHeight())+(1d / 100 * height)));
views.get("btnspeaker").vw.setLeft((int)((views.get("btnleft").vw.getLeft() + views.get("btnleft").vw.getWidth())+(3d / 100 * width)));
views.get("btnspeaker").vw.setWidth((int)((14d / 100 * width)));
views.get("btnspeaker").vw.setHeight((int)((8d / 100 * height)));
views.get("lbltemp").vw.setLeft((int)((views.get("btnbacktemp").vw.getLeft())));
views.get("lbltemp").vw.setWidth((int)((views.get("btnbacktemp").vw.getWidth())));
views.get("lbltemp").vw.setHeight((int)((6d / 100 * height)));
views.get("lbltemp").vw.setTop((int)((views.get("btnbacktemp").vw.getTop() + views.get("btnbacktemp").vw.getHeight())));
views.get("btnsmartmove").vw.setTop((int)((views.get("btndown").vw.getTop() + views.get("btndown").vw.getHeight())+(9d / 100 * height)));
views.get("btnsmartmove").vw.setLeft((int)((3d / 100 * width)));
views.get("btnsmartmove").vw.setWidth((int)((63d / 100 * width)));
//BA.debugLineNum = 48;BA.debugLine="btnSmartMove.Height = 12%y"[MainLayout/General script]
views.get("btnsmartmove").vw.setHeight((int)((12d / 100 * height)));
//BA.debugLineNum = 50;BA.debugLine="btnLomp1.Top = btnDown.Bottom + 9%y"[MainLayout/General script]
views.get("btnlomp1").vw.setTop((int)((views.get("btndown").vw.getTop() + views.get("btndown").vw.getHeight())+(9d / 100 * height)));
//BA.debugLineNum = 51;BA.debugLine="btnLomp1.Left = btnSmartMove.Right + 4%x"[MainLayout/General script]
views.get("btnlomp1").vw.setLeft((int)((views.get("btnsmartmove").vw.getLeft() + views.get("btnsmartmove").vw.getWidth())+(4d / 100 * width)));
//BA.debugLineNum = 52;BA.debugLine="btnLomp1.Width = 25%x"[MainLayout/General script]
views.get("btnlomp1").vw.setWidth((int)((25d / 100 * width)));
//BA.debugLineNum = 53;BA.debugLine="btnLomp1.Height = 13%y"[MainLayout/General script]
views.get("btnlomp1").vw.setHeight((int)((13d / 100 * height)));
//BA.debugLineNum = 55;BA.debugLine="btnSettings.Top = 2%y"[MainLayout/General script]
views.get("btnsettings").vw.setTop((int)((2d / 100 * height)));
//BA.debugLineNum = 56;BA.debugLine="btnSettings.Left = 3%x"[MainLayout/General script]
views.get("btnsettings").vw.setLeft((int)((3d / 100 * width)));
//BA.debugLineNum = 58;BA.debugLine="btnConnect.Top = btnSettings.Top"[MainLayout/General script]
views.get("btnconnect").vw.setTop((int)((views.get("btnsettings").vw.getTop())));
//BA.debugLineNum = 59;BA.debugLine="btnConnect.Left = btnSettings.Right + 4%x"[MainLayout/General script]
views.get("btnconnect").vw.setLeft((int)((views.get("btnsettings").vw.getLeft() + views.get("btnsettings").vw.getWidth())+(4d / 100 * width)));
//BA.debugLineNum = 61;BA.debugLine="btnDisconnect.Top = btnSettings.Top"[MainLayout/General script]
views.get("btndisconnect").vw.setTop((int)((views.get("btnsettings").vw.getTop())));
//BA.debugLineNum = 62;BA.debugLine="btnDisconnect.Left = btnConnect.Right + 2%x"[MainLayout/General script]
views.get("btndisconnect").vw.setLeft((int)((views.get("btnconnect").vw.getLeft() + views.get("btnconnect").vw.getWidth())+(2d / 100 * width)));
//BA.debugLineNum = 64;BA.debugLine="lblDistance.Top = btnSettings.Bottom + 5%y"[MainLayout/General script]
views.get("lbldistance").vw.setTop((int)((views.get("btnsettings").vw.getTop() + views.get("btnsettings").vw.getHeight())+(5d / 100 * height)));
//BA.debugLineNum = 65;BA.debugLine="lblDistance.Left = btnSettings.Left"[MainLayout/General script]
views.get("lbldistance").vw.setLeft((int)((views.get("btnsettings").vw.getLeft())));
//BA.debugLineNum = 66;BA.debugLine="lblDistance.Width = 65%x"[MainLayout/General script]
views.get("lbldistance").vw.setWidth((int)((65d / 100 * width)));
//BA.debugLineNum = 67;BA.debugLine="lblDistance.Height = 20%x"[MainLayout/General script]
views.get("lbldistance").vw.setHeight((int)((20d / 100 * width)));
//BA.debugLineNum = 69;BA.debugLine="lblDistanceTxt.Top = lblDistance.Top - 1.5%y"[MainLayout/General script]
views.get("lbldistancetxt").vw.setTop((int)((views.get("lbldistance").vw.getTop())-(1.5d / 100 * height)));
//BA.debugLineNum = 70;BA.debugLine="lblDistanceTxt.Left = lblDistance.Left + 13%x"[MainLayout/General script]
views.get("lbldistancetxt").vw.setLeft((int)((views.get("lbldistance").vw.getLeft())+(13d / 100 * width)));
//BA.debugLineNum = 72;BA.debugLine="sbSpead.Top = lblDistance.Bottom + 9%y"[MainLayout/General script]
views.get("sbspead").vw.setTop((int)((views.get("lbldistance").vw.getTop() + views.get("lbldistance").vw.getHeight())+(9d / 100 * height)));
//BA.debugLineNum = 73;BA.debugLine="sbSpead.Left = lblDistance.Left"[MainLayout/General script]
views.get("sbspead").vw.setLeft((int)((views.get("lbldistance").vw.getLeft())));
//BA.debugLineNum = 74;BA.debugLine="sbSpead.Width = 70%x"[MainLayout/General script]
views.get("sbspead").vw.setWidth((int)((70d / 100 * width)));
//BA.debugLineNum = 76;BA.debugLine="etSpead.Top = sbSpead.Top - 7%y"[MainLayout/General script]
views.get("etspead").vw.setTop((int)((views.get("sbspead").vw.getTop())-(7d / 100 * height)));
//BA.debugLineNum = 77;BA.debugLine="etSpead.Width = 17%x"[MainLayout/General script]
views.get("etspead").vw.setWidth((int)((17d / 100 * width)));
//BA.debugLineNum = 78;BA.debugLine="etSpead.Left = sbSpead.Left + 25%x"[MainLayout/General script]
views.get("etspead").vw.setLeft((int)((views.get("sbspead").vw.getLeft())+(25d / 100 * width)));
//BA.debugLineNum = 79;BA.debugLine="etSpead.Height = 6%y"[MainLayout/General script]
views.get("etspead").vw.setHeight((int)((6d / 100 * height)));
//BA.debugLineNum = 81;BA.debugLine="lblTxtSpeed.Top = etSpead.Top"[MainLayout/General script]
views.get("lbltxtspeed").vw.setTop((int)((views.get("etspead").vw.getTop())));
//BA.debugLineNum = 82;BA.debugLine="lblTxtSpeed.Left = sbSpead.Left + 2.5%x"[MainLayout/General script]
views.get("lbltxtspeed").vw.setLeft((int)((views.get("sbspead").vw.getLeft())+(2.5d / 100 * width)));
//BA.debugLineNum = 83;BA.debugLine="lblTxtSpeed.Width = 20%x"[MainLayout/General script]
views.get("lbltxtspeed").vw.setWidth((int)((20d / 100 * width)));
//BA.debugLineNum = 84;BA.debugLine="lblTxtSpeed.Height = 6%y"[MainLayout/General script]
views.get("lbltxtspeed").vw.setHeight((int)((6d / 100 * height)));

}
}
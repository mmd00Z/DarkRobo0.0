package com.DarkRobo.mmd.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_aboutlayoutlight{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
//BA.debugLineNum = 2;BA.debugLine="AutoScaleAll"[AboutLayoutLight/General script]
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
//BA.debugLineNum = 4;BA.debugLine="lblTxtAbout.Top = 0%y"[AboutLayoutLight/General script]
views.get("lbltxtabout").vw.setTop((int)((0d / 100 * height)));
//BA.debugLineNum = 5;BA.debugLine="lblTxtAbout.Left = 0%x"[AboutLayoutLight/General script]
views.get("lbltxtabout").vw.setLeft((int)((0d / 100 * width)));
//BA.debugLineNum = 6;BA.debugLine="lblTxtAbout.Width = 100%x"[AboutLayoutLight/General script]
views.get("lbltxtabout").vw.setWidth((int)((100d / 100 * width)));
//BA.debugLineNum = 7;BA.debugLine="lblTxtAbout.Height = 9%y"[AboutLayoutLight/General script]
views.get("lbltxtabout").vw.setHeight((int)((9d / 100 * height)));
//BA.debugLineNum = 9;BA.debugLine="btnBack.Top = 1%y"[AboutLayoutLight/General script]
views.get("btnback").vw.setTop((int)((1d / 100 * height)));
//BA.debugLineNum = 10;BA.debugLine="btnBack.Left = 2%x"[AboutLayoutLight/General script]
views.get("btnback").vw.setLeft((int)((2d / 100 * width)));
//BA.debugLineNum = 11;BA.debugLine="btnBack.Width = 14%x"[AboutLayoutLight/General script]
views.get("btnback").vw.setWidth((int)((14d / 100 * width)));
//BA.debugLineNum = 12;BA.debugLine="btnBack.Height = 7%y"[AboutLayoutLight/General script]
views.get("btnback").vw.setHeight((int)((7d / 100 * height)));
//BA.debugLineNum = 14;BA.debugLine="imgLogo.Top = 10%y"[AboutLayoutLight/General script]
views.get("imglogo").vw.setTop((int)((10d / 100 * height)));
//BA.debugLineNum = 15;BA.debugLine="imgLogo.Left = 18%x"[AboutLayoutLight/General script]
views.get("imglogo").vw.setLeft((int)((18d / 100 * width)));
//BA.debugLineNum = 16;BA.debugLine="imgLogo.Width = 64%x"[AboutLayoutLight/General script]
views.get("imglogo").vw.setWidth((int)((64d / 100 * width)));
//BA.debugLineNum = 17;BA.debugLine="imgLogo.Height = 30%y"[AboutLayoutLight/General script]
views.get("imglogo").vw.setHeight((int)((30d / 100 * height)));
//BA.debugLineNum = 19;BA.debugLine="lblDescriptionApp.Top = imgLogo.Bottom + 1%y"[AboutLayoutLight/General script]
views.get("lbldescriptionapp").vw.setTop((int)((views.get("imglogo").vw.getTop() + views.get("imglogo").vw.getHeight())+(1d / 100 * height)));
//BA.debugLineNum = 20;BA.debugLine="lblDescriptionApp.Left = 3%x"[AboutLayoutLight/General script]
views.get("lbldescriptionapp").vw.setLeft((int)((3d / 100 * width)));
//BA.debugLineNum = 21;BA.debugLine="lblDescriptionApp.Width = 94%x"[AboutLayoutLight/General script]
views.get("lbldescriptionapp").vw.setWidth((int)((94d / 100 * width)));
//BA.debugLineNum = 22;BA.debugLine="lblDescriptionApp.Height = 32%y"[AboutLayoutLight/General script]
views.get("lbldescriptionapp").vw.setHeight((int)((32d / 100 * height)));
//BA.debugLineNum = 24;BA.debugLine="lblDescriptionAppEN.Top = lblDescriptionApp.Top"[AboutLayoutLight/General script]
views.get("lbldescriptionappen").vw.setTop((int)((views.get("lbldescriptionapp").vw.getTop())));
//BA.debugLineNum = 25;BA.debugLine="lblDescriptionAppEN.Left = lblDescriptionApp.Left"[AboutLayoutLight/General script]
views.get("lbldescriptionappen").vw.setLeft((int)((views.get("lbldescriptionapp").vw.getLeft())));
//BA.debugLineNum = 26;BA.debugLine="lblDescriptionAppEN.Width = lblDescriptionApp.Width"[AboutLayoutLight/General script]
views.get("lbldescriptionappen").vw.setWidth((int)((views.get("lbldescriptionapp").vw.getWidth())));
//BA.debugLineNum = 27;BA.debugLine="lblDescriptionAppEN.Height = lblDescriptionApp.Height"[AboutLayoutLight/General script]
views.get("lbldescriptionappen").vw.setHeight((int)((views.get("lbldescriptionapp").vw.getHeight())));
//BA.debugLineNum = 29;BA.debugLine="lblHoghogh.Top = lblDescriptionApp.Bottom + 1%y"[AboutLayoutLight/General script]
views.get("lblhoghogh").vw.setTop((int)((views.get("lbldescriptionapp").vw.getTop() + views.get("lbldescriptionapp").vw.getHeight())+(1d / 100 * height)));
//BA.debugLineNum = 30;BA.debugLine="lblHoghogh.Left = 1%x"[AboutLayoutLight/General script]
views.get("lblhoghogh").vw.setLeft((int)((1d / 100 * width)));
//BA.debugLineNum = 31;BA.debugLine="lblHoghogh.Width = 98%x"[AboutLayoutLight/General script]
views.get("lblhoghogh").vw.setWidth((int)((98d / 100 * width)));
//BA.debugLineNum = 32;BA.debugLine="lblHoghogh.Height = 7%y"[AboutLayoutLight/General script]
views.get("lblhoghogh").vw.setHeight((int)((7d / 100 * height)));
//BA.debugLineNum = 34;BA.debugLine="img_family.Top = lblHoghogh.Bottom + 5%y"[AboutLayoutLight/General script]
views.get("img_family").vw.setTop((int)((views.get("lblhoghogh").vw.getTop() + views.get("lblhoghogh").vw.getHeight())+(5d / 100 * height)));
//BA.debugLineNum = 35;BA.debugLine="img_family.Left = 5%x"[AboutLayoutLight/General script]
views.get("img_family").vw.setLeft((int)((5d / 100 * width)));
//BA.debugLineNum = 36;BA.debugLine="img_family.Width = 25%x"[AboutLayoutLight/General script]
views.get("img_family").vw.setWidth((int)((25d / 100 * width)));
//BA.debugLineNum = 37;BA.debugLine="img_family.Height = 12%y"[AboutLayoutLight/General script]
views.get("img_family").vw.setHeight((int)((12d / 100 * height)));
//BA.debugLineNum = 39;BA.debugLine="img_marlik.Top = img_family.Top"[AboutLayoutLight/General script]
views.get("img_marlik").vw.setTop((int)((views.get("img_family").vw.getTop())));
//BA.debugLineNum = 40;BA.debugLine="img_marlik.Left = img_family.Right + 3%x"[AboutLayoutLight/General script]
views.get("img_marlik").vw.setLeft((int)((views.get("img_family").vw.getLeft() + views.get("img_family").vw.getWidth())+(3d / 100 * width)));
//BA.debugLineNum = 41;BA.debugLine="img_marlik.Width = img_family.Width"[AboutLayoutLight/General script]
views.get("img_marlik").vw.setWidth((int)((views.get("img_family").vw.getWidth())));
//BA.debugLineNum = 42;BA.debugLine="img_marlik.Height = img_family.Height"[AboutLayoutLight/General script]
views.get("img_marlik").vw.setHeight((int)((views.get("img_family").vw.getHeight())));
//BA.debugLineNum = 44;BA.debugLine="lblTxtHamis.Top = img_family.Top '+ 2%y"[AboutLayoutLight/General script]
views.get("lbltxthamis").vw.setTop((int)((views.get("img_family").vw.getTop())));
//BA.debugLineNum = 45;BA.debugLine="lblTxtHamis.Left = img_marlik.Right + 5%x"[AboutLayoutLight/General script]
views.get("lbltxthamis").vw.setLeft((int)((views.get("img_marlik").vw.getLeft() + views.get("img_marlik").vw.getWidth())+(5d / 100 * width)));
//BA.debugLineNum = 46;BA.debugLine="lblTxtHamis.Width = 35%x"[AboutLayoutLight/General script]
views.get("lbltxthamis").vw.setWidth((int)((35d / 100 * width)));
//BA.debugLineNum = 47;BA.debugLine="lblTxtHamis.Height = 8%y"[AboutLayoutLight/General script]
views.get("lbltxthamis").vw.setHeight((int)((8d / 100 * height)));

}
}
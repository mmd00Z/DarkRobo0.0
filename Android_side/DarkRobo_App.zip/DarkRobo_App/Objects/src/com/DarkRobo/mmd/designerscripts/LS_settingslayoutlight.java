package com.DarkRobo.mmd.designerscripts;
import anywheresoftware.b4a.objects.TextViewWrapper;
import anywheresoftware.b4a.objects.ImageViewWrapper;
import anywheresoftware.b4a.BA;


public class LS_settingslayoutlight{

public static void LS_general(java.util.LinkedHashMap<String, anywheresoftware.b4a.keywords.LayoutBuilder.ViewWrapperAndAnchor> views, int width, int height, float scale) {
anywheresoftware.b4a.keywords.LayoutBuilder.setScaleRate(0.3);
anywheresoftware.b4a.keywords.LayoutBuilder.scaleAll(views);
views.get("lbltxtsetting").vw.setTop((int)((0d / 100 * height)));
views.get("lbltxtsetting").vw.setLeft((int)((0d / 100 * width)));
views.get("lbltxtsetting").vw.setWidth((int)((100d / 100 * width)));
views.get("lbltxtsetting").vw.setHeight((int)((10d / 100 * height)));
views.get("btnback").vw.setTop((int)((1d / 100 * height)));
views.get("btnback").vw.setLeft((int)((2d / 100 * width)));
views.get("btnback").vw.setWidth((int)((15d / 100 * width)));
views.get("btnback").vw.setHeight((int)((8d / 100 * height)));
views.get("btnabout").vw.setTop((int)((1d / 100 * height)));
views.get("btnabout").vw.setLeft((int)((82d / 100 * width)));
views.get("btnabout").vw.setWidth((int)((16d / 100 * width)));
views.get("btnabout").vw.setHeight((int)((8d / 100 * height)));
views.get("lbltxtlanguage").vw.setTop((int)((views.get("lbltxtsetting").vw.getTop() + views.get("lbltxtsetting").vw.getHeight())+(8d / 100 * height)));
views.get("lbltxtlanguage").vw.setLeft((int)((3d / 100 * width)));
views.get("lbltxtlanguage").vw.setWidth((int)((30d / 100 * width)));
views.get("lbltxtlanguage").vw.setHeight((int)((6d / 100 * height)));
views.get("spinnerlanguage").vw.setTop((int)((views.get("lbltxtlanguage").vw.getTop() + views.get("lbltxtlanguage").vw.getHeight())));
views.get("spinnerlanguage").vw.setLeft((int)((3d / 100 * width)));
views.get("spinnerlanguage").vw.setWidth((int)((94d / 100 * width)));
views.get("spinnerlanguage").vw.setHeight((int)((9d / 100 * height)));
views.get("lbltxttheme").vw.setTop((int)((views.get("spinnerlanguage").vw.getTop() + views.get("spinnerlanguage").vw.getHeight())+(14d / 100 * height)));
views.get("lbltxttheme").vw.setLeft((int)((3d / 100 * width)));
views.get("lbltxttheme").vw.setWidth((int)((30d / 100 * width)));
views.get("lbltxttheme").vw.setHeight((int)((6d / 100 * height)));
views.get("rblight").vw.setTop((int)((views.get("lbltxttheme").vw.getTop() + views.get("lbltxttheme").vw.getHeight())+(1d / 100 * width)));
views.get("rblight").vw.setLeft((int)((3d / 100 * width)));
views.get("rblight").vw.setWidth((int)((46d / 100 * width)));
views.get("rblight").vw.setHeight((int)((9d / 100 * height)));
views.get("rbdark").vw.setTop((int)((views.get("rblight").vw.getTop())));
views.get("rbdark").vw.setLeft((int)((51d / 100 * width)));
views.get("rbdark").vw.setWidth((int)((views.get("rblight").vw.getWidth())));
views.get("rbdark").vw.setHeight((int)((views.get("rblight").vw.getHeight())));
views.get("btncancel").vw.setTop((int)((88d / 100 * height)));
views.get("btncancel").vw.setLeft((int)((3d / 100 * width)));
views.get("btncancel").vw.setWidth((int)((46d / 100 * width)));
views.get("btncancel").vw.setHeight((int)((9d / 100 * height)));
views.get("btnok").vw.setTop((int)((views.get("btncancel").vw.getTop())));
views.get("btnok").vw.setLeft((int)((51d / 100 * width)));
views.get("btnok").vw.setWidth((int)((views.get("btncancel").vw.getWidth())));
views.get("btnok").vw.setHeight((int)((views.get("btncancel").vw.getHeight())));

}
}